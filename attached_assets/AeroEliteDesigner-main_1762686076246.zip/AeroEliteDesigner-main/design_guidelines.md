# Aero Elite - Design Guidelines

## Design Approach

**Selected Approach:** Design System + Industry Reference Hybrid

**Primary System:** Fluent Design System (Microsoft) - optimized for data-dense productivity applications with strong information architecture

**Industry References:** Autodesk Fusion 360 and CATIA aerospace interfaces for professional CAD patterns, panel layouts, and technical precision

**Core Principles:**
- Functional clarity over decoration
- Information density with breathing room
- Technical precision and accuracy
- Professional workspace efficiency

---

## Typography System

**Font Families:**
- Primary: Inter (interface, labels, data)
- Secondary: JetBrains Mono (technical specs, measurements, parameters)

**Hierarchy:**
- Display (3xl/4xl): Main headings, section titles
- Heading (xl/2xl): Panel headers, component names
- Body (base/sm): Parameter labels, descriptions
- Technical (sm mono): Measurements, coordinates, specifications
- Caption (xs): Metadata, timestamps, units

**Weights:** 400 (regular), 500 (medium), 600 (semibold) for hierarchy

---

## Layout System

**Spacing Primitives:** Tailwind units of **2, 3, 4, 6, 8, 12** for consistency
- Micro spacing: 2, 3 (icon gaps, tight elements)
- Standard spacing: 4, 6 (component padding, gaps)
- Section spacing: 8, 12 (panel margins, major separations)

**Core Layout Structure:**

**App Shell:**
- Top navbar: h-16 with logo, navigation, user menu
- Left sidebar: w-64 collapsible tool panel with parametric controls
- Main canvas: Flex-grow 3D viewer area
- Right panel: w-80 specifications and properties inspector
- Bottom toolbar: h-12 with quick actions and status

**Grid System:**
- 12-column grid for complex layouts
- Max-width containers: max-w-7xl for main content areas
- Panels use fixed widths (w-64, w-80) for consistency

---

## Component Library

### Navigation & Structure

**Top Navigation Bar:**
- Logo and app name (left)
- Primary actions: "New Design", "Open", "Save" (center-left)
- User profile, settings, theme toggle (right)
- Height: h-16, items with px-4 spacing

**Sidebar Tool Panel:**
- Collapsible accordion sections for component categories
- "Wings", "Fuselage", "Engines", "Tail", "Landing Gear"
- Each section expands to show templates and parameters
- Search input at top for quick access

**3D Viewport Area:**
- Full-height flex-grow canvas
- Floating control overlays (top-right): View controls, render modes
- Grid floor reference with measurement indicators
- Corner compass/axis indicator

**Properties Panel:**
- Sticky header with component name
- Tabbed interface: "Parameters", "Materials", "Analysis"
- Scrollable content area with grouped parameter fields
- Action buttons at bottom: "Apply", "Reset"

### Forms & Inputs

**Natural Language Input:**
- Large textarea (min-h-32) with placeholder: "Describe your aircraft component..."
- Character counter and AI indicator
- "Generate" button with loading state
- Quick prompt examples as chips below

**Parameter Fields:**
- Label + input + unit in compact rows (grid grid-cols-[120px_1fr_60px])
- Number inputs with increment/decrement steppers
- Validation indicators inline
- Grouped by category with subtle dividers

**Dropdowns & Selects:**
- Material selector with preview swatches
- Template picker with thumbnail previews
- Consistent h-10 for all interactive elements

### Data Display

**Specification Cards:**
- Grid of 2-3 columns for key metrics
- Each card: p-4, rounded-lg border
- Large value (text-2xl font-semibold) with label below (text-sm)
- Icon indicator for metric type

**3D Model Metadata:**
- List view with label-value pairs
- Technical details in monospace font
- Collapsible sections for detailed specs
- Export format options with checkboxes

**History Panel:**
- Timeline view of design iterations
- Thumbnail + timestamp + description
- Click to restore previous state

### Interactive Elements

**Action Buttons:**
- Primary: Prominent for "Generate", "Apply", "Export"
- Secondary: For "Cancel", "Reset", supporting actions
- Icon buttons: For tools, view controls (h-10 w-10)
- Consistent px-6 py-2.5 padding for text buttons

**3D Viewer Controls:**
- Floating toolbar (top-right): Rotate, Pan, Zoom icons
- View presets: "Front", "Top", "Side", "Isometric" as button group
- Measurement tools toggle
- Screenshot/export viewport button

**Toggles & Switches:**
- Dark/Light mode toggle in header
- Grid visibility, axis display, measurement overlay switches
- Grouped in settings menu

### Overlays & Modals

**Authentication Modal:**
- Centered card (max-w-md)
- Google OAuth button with icon
- Email/password fields with proper spacing (space-y-4)
- "Sign In" / "Sign Up" toggle
- Password reset link

**Export Dialog:**
- File format selection (OBJ, STL, STEP)
- Quality/resolution slider
- Preview of export settings
- Download progress indicator

**Confirmation Dialogs:**
- Compact (max-w-sm) with clear message
- Icon indicator for action type
- "Confirm" / "Cancel" buttons aligned right

---

## Interactions & Animations

**Minimal Animation Strategy:**
- Panel slide transitions (300ms ease)
- Button hover states (subtle scale/shadow)
- Loading spinners for AI generation
- Smooth 3D canvas orbit/zoom
- NO decorative animations, NO scroll effects

---

## Image Strategy

**No Hero Images** - This is a professional tool, not marketing

**Images Used:**
- 3D model thumbnails in history/templates (64x64, 128x128)
- Material/texture previews in selectors
- User avatars (rounded-full, h-8 w-8)
- Empty state illustrations for "no models" (max-w-xs)
- Tutorial/onboarding diagrams if needed

**Image Placement:**
- Template library: Grid of component thumbnails with labels
- Material selector: Small preview swatches next to names
- User menu: Avatar in top-right navigation

---

## Responsive Behavior

**Desktop-First:** Optimized for 1920x1080+ workflows

**Tablet (md):**
- Collapse left sidebar to icon-only
- Stack panels vertically for smaller screens
- Maintain 3D viewport as primary focus

**Mobile (sm):**
- Bottom tab bar navigation
- Full-screen 3D viewer
- Drawer overlays for tools/properties
- Simplified parameter inputs

---

## Accessibility

- Consistent focus indicators (ring-2 offset-2)
- ARIA labels for all icon buttons
- Keyboard shortcuts for common actions (Ctrl+N, Ctrl+S, etc.)
- High contrast maintained throughout
- Screen reader friendly form labels and structure