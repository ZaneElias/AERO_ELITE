# Aero Elite - AI-Assisted 3D Aircraft Design

## Overview

Aero Elite is an AI-powered 3D aircraft design platform that enables users to generate detailed aircraft component models from natural language descriptions. The application combines aerospace engineering principles with modern AI capabilities to transform text prompts (e.g., "Generate a left wing with 35° sweep, 35m span, carbon composite skeleton") into parametric 3D models.

**Core Capabilities:**
- Natural language to 3D aircraft component generation with procedural geometry
- Real-time parametric model visualization using Three.js with NACA airfoil profiles
- AI-powered parameter extraction using Google's Gemini 2.5 Flash
- Professional CAD-inspired interface with viewport HUD, camera presets, and tabbed properties
- GLB/GLTF export for use in Blender, Unity, and other 3D software
- Support for multiple aircraft components: swept wings with taper, fuselages with nose/tail cones, engine nacelles, vertical/horizontal stabilizers, and complete assemblies

**Target Users:** Aerospace engineers, students, and design enthusiasts who need rapid prototyping and visualization of aircraft designs without extensive CAD expertise.

## Recent Changes (November 2025)

### Latest Update - Backend Enhancement & Pre-built Aircraft Library (Nov 9, 2025)
Fixed critical bugs and added intelligent AI features with pre-built aircraft templates:

**Critical Bug Fixes:**
- ✅ Fixed 3D viewer runtime error (replaced gridHelper with Grid component from drei)
- ✅ Removed invalid shadow props from Three.js lighting
- ✅ 3D viewer now renders correctly with proper grid and lighting

**AI Intelligence Enhancements:**
- ✅ Enhanced Gemini AI with aerospace domain knowledge (F-16, 737, 747, A380, F-22 specs)
- ✅ Intelligent parameter inference based on aircraft type (fighter → 35-45° sweep, commercial → 25-35° sweep)
- ✅ AI now suggests realistic defaults when values not specified
- ✅ Improved error handling for Meshy API (401/402/404 errors with clear messages)

**Pre-built Aircraft Template Library:**
- ✅ Added 10 professional aircraft templates ready to use
- ✅ Military: F-16 Fighting Falcon, F-22 Raptor, MiG-29 Fulcrum
- ✅ Commercial: Boeing 737-800, Boeing 747-400, Airbus A380
- ✅ General Aviation: Cessna 172 Skyhawk
- ✅ Components: Generic fighter wing, commercial wing, narrow-body fuselage
- ✅ Templates grouped by category (Military/Commercial/Components)
- ✅ One-click loading of any template into the 3D viewer

### Major Rebuild - Parametric Geometry and CAD UI
Completely rebuilt the 3D viewer and UI to transform Aero Elite into a professional aerospace CAD tool:

**3D Parametric Geometry Engine:**
- ✅ Procedural wing generation using NACA 4-digit airfoil profiles with proper sweep angles, span, chord, and taper
- ✅ Procedural fuselage with elliptical nose cone (15%), cylindrical body (60%), and smooth tail cone (25%)
- ✅ Engine nacelles with intake, main body, and exhaust
- ✅ Vertical and horizontal stabilizers (tail sections)
- ✅ WebGL detection with iframe fallback (opens in new tab for Replit preview)
- ✅ All parameters (sweep, span, chord, length, diameter) accurately applied to geometry

**3D Model Export:**
- ✅ GLTFExporter integration for binary .glb downloads
- ✅ Export from viewer overlay button or top navbar
- ✅ Descriptive filenames based on component type and parameters
- ✅ Files compatible with Blender, Unity, and other 3D software

**CAD-Style UI Enhancements:**
- ✅ Viewport HUD showing view mode, grid status, and camera distance (bottom-left overlay)
- ✅ Camera view presets: Top, Front, Right, Isometric with smooth animations
- ✅ Enhanced component library with card-based thumbnails and icons
- ✅ Tabbed properties panel (Parameters / Materials / Export)
- ✅ Material controls for metalness and roughness
- ✅ Professional aerospace design theme throughout

**Authentication & OAuth:**
- ✅ Google OAuth fully implemented with Passport.js
- ✅ Iframe detection for Replit preview (opens OAuth in new window)
- ✅ Session management with secure cookies
- ✅ Protected design endpoints with user ownership checks

**Meshy API Integration:**
- ✅ Made optional with clear paid plan messaging (~$16/month)
- ✅ AlertDialog warns users before first use
- ✅ localStorage tracks user's paid plan opt-in
- ✅ Enhanced error handling for 402 errors with upgrade guidance
- ✅ Parametric generation emphasized as the primary FREE feature

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework:** React 18 with TypeScript, built using Vite for fast development and optimized production builds.

**UI Component System:**
- **Design System:** Custom implementation based on shadcn/ui (Radix UI primitives)
- **Styling:** Tailwind CSS with custom design tokens following Fluent Design System
- **Typography:** Inter for UI elements, JetBrains Mono for technical specifications
- **Theme System:** Dark/light mode support with CSS variables for dynamic theming

**3D Rendering Stack:**
- **Renderer:** Three.js via @react-three/fiber
- **Helpers:** @react-three/drei for camera controls, lighting, and scene utilities
- **Approach:** Parametric geometry generation based on extracted design parameters
- **Rationale:** Three.js provides WebGL rendering without requiring browser plugins, while React-Three-Fiber enables declarative 3D scene composition that integrates seamlessly with React's component model

**State Management:**
- **Query Management:** TanStack Query (React Query) for server state
- **Local State:** React hooks (useState, useContext) for UI state
- **Form State:** React Hook Form with Zod validation
- **Routing:** Wouter for lightweight client-side routing

**Layout Structure:**
- **App Shell:** Fixed top navbar (h-16) with logo, actions, and user menu
- **Left Sidebar:** Collapsible tool panel (w-64) for component library and templates
- **Main Canvas:** Flex-grow 3D viewer area with orbit controls
- **Right Panel:** Properties inspector (w-80) with tabbed interface for parameters and specifications
- **Bottom Toolbar:** Status bar with view controls and quick actions

### Backend Architecture

**Runtime:** Node.js with Express.js framework

**API Design:**
- **Pattern:** RESTful API with JSON payloads
- **Endpoints:** Single primary endpoint `/api/extract-parameters` for AI parameter extraction
- **Session Management:** In-memory storage (MemStorage class) for development, designed for future database integration
- **Middleware:** Express.json for request parsing, custom logging middleware for API request tracking

**AI Integration:**
- **Provider:** Google Gemini 2.5 Flash via @google/genai SDK (updated Nov 2025 - migrated from deprecated 1.5 models)
- **Purpose:** Extracts structured aircraft design parameters from natural language prompts
- **System Prompt:** Aerospace engineer persona that identifies component types and extracts numerical parameters (sweep, span, chord, length, diameter, material, thrust, count)
- **Output Format:** Structured JSON validated against Zod schemas
- **Error Handling:** Returns 400-level errors for invalid prompts, 500 for AI/server errors
- **Status:** ✅ Working - Tested with natural language input "Design a wing with 45 degree sweep angle and 40 meter span" successfully extracting componentType:wing, sweep:45°, span:40m

**Build System:**
- **Development:** tsx for TypeScript execution with hot reload
- **Production:** esbuild for server bundling, Vite for client bundling
- **Output:** Separate dist/public for client assets, dist for server code

### Data Storage Solutions

**Current Implementation:**
- **Type:** In-memory storage using JavaScript Map objects
- **Scope:** User authentication data (username, hashed password, UUID)
- **Rationale:** Simplifies development setup without external dependencies

**Database Integration (Configured but not active):**
- **Provider:** Neon Serverless PostgreSQL via @neondatabase/serverless
- **ORM:** Drizzle ORM with TypeScript schemas
- **Connection:** WebSocket-based connection pooling for serverless environments
- **Schema:** Defined in shared/schema.ts with users table and aircraft parameters types
- **Migration Strategy:** Drizzle Kit for schema migrations (drizzle.config.ts)
- **Future Intent:** Persist user designs, parameter templates, and model metadata

**Schema Design:**
- **Users Table:** id (UUID), username (unique), password (hashed)
- **Aircraft Parameters:** Zod schemas defining componentType (enum), dimensional parameters (sweep, span, chord, length, diameter), material properties, and performance specs (thrust, count)
- **Validation:** Shared schemas between client and server ensure type safety across the stack

### Authentication and Authorization

**Current State:** Placeholder authentication UI without active implementation

**Designed Mechanisms:**
- **UI Components:** AuthDialog with tabs for sign-in/sign-up
- **Planned Methods:** 
  - Email/password with verification
  - Google OAuth integration (UI ready with SiGoogle icon)
- **Session Storage:** In-memory user storage with UUID-based identification
- **Future Enhancement:** JWT or session-based authentication with secure password hashing (bcrypt/argon2)

**Authorization Model:** Currently no role-based access control; designed for single-user sessions with plans for project ownership and sharing capabilities.

### External Dependencies

**AI Services:**
- **Google Gemini API (Required):** Natural language understanding and parameter extraction for the FREE parametric generator
  - **API Key:** Required via GEMINI_API_KEY environment variable
  - **Rate Limits:** Handled through SDK; no explicit retry logic implemented
  - **Purpose:** Powers the primary free parametric 3D aircraft component generation
  
- **Meshy AI (Optional - Paid Service):** Photorealistic 3D model generation
  - **Cost:** Requires paid subscription (~$16/month at meshy.ai/settings/subscription)
  - **Status:** Optional third-party integration for advanced photorealistic renders
  - **API Key:** MESHY_API_KEY environment variable (only if user has paid plan)
  - **Error Handling:** 402 errors show user-friendly messages with upgrade links
  - **User Flow:** Confirmation dialog warns users about paid subscription before first use
  - **Storage:** User's paid plan preference stored in localStorage ("meshyPaidPlanEnabled")
  - **Note:** The free parametric generator is the primary feature; Meshy is purely optional

**Database Service:**
- **Neon Serverless PostgreSQL:** Cloud-hosted Postgres with serverless architecture
- **Connection:** DATABASE_URL environment variable required
- **WebSocket Protocol:** Uses ws package for Neon's WebSocket-based connections
- **Benefits:** Auto-scaling, branching for preview environments, zero cold starts

**Font Services:**
- **Google Fonts:** Inter (400, 500, 600, 700) and JetBrains Mono (400, 500, 600)
- **Loading Strategy:** Preconnect for performance optimization

**Third-Party Libraries:**
- **UI Components:** Radix UI primitives (@radix-ui/*) for accessible component foundations
- **3D Graphics:** Three.js, React-Three-Fiber, React-Three-Drei
- **Utilities:** clsx, tailwind-merge for className management; class-variance-authority for variant-based styling
- **Development Tools:** Replit plugins for runtime error overlay, cartographer, and dev banner

**Dataset References (Planned Integration):**
- **AircraftVerse:** 27,714 aircraft designs for ML training (Zenodo)
- **G2Aero:** 19,164 airfoil profiles (OpenEI)
- **NASA CRM:** Validated geometry CAD files (NASA LaRC)
- **Usage:** Future training data for improving AI parameter extraction and model generation accuracy