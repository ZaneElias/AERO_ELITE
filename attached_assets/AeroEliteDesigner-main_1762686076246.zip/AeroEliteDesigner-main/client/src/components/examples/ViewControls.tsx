import { ViewControls } from "../ViewControls";

export default function ViewControlsExample() {
  return (
    <div className="relative h-[300px] bg-background p-4">
      <ViewControls />
    </div>
  );
}
