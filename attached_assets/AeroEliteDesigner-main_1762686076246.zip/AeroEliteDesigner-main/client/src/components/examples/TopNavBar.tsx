import { TopNavBar } from "../TopNavBar";
import { ThemeProvider } from "../ThemeProvider";

export default function TopNavBarExample() {
  return (
    <ThemeProvider>
      <div className="bg-background">
        <TopNavBar />
      </div>
    </ThemeProvider>
  );
}
