import { ComponentLibrary } from "../ComponentLibrary";

export default function ComponentLibraryExample() {
  return (
    <div className="w-[280px] bg-background">
      <ComponentLibrary />
    </div>
  );
}
