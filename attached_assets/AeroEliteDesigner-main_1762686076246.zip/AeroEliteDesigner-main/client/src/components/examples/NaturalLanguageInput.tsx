import { NaturalLanguageInput } from "../NaturalLanguageInput";

export default function NaturalLanguageInputExample() {
  return (
    <div className="p-4 bg-background">
      <NaturalLanguageInput onParametersExtracted={(params, explanation) => console.log("Generated:", params, explanation)} />
    </div>
  );
}
