import { SpecificationCard } from "../SpecificationCard";
import { Ruler } from "lucide-react";

export default function SpecificationCardExample() {
  return (
    <div className="p-4 bg-background">
      <SpecificationCard
        icon={Ruler}
        label="Wingspan"
        value={35}
        unit="m"
        testId="spec-wingspan"
      />
    </div>
  );
}
