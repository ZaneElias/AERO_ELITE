import { PropertiesPanel } from "../PropertiesPanel";

export default function PropertiesPanelExample() {
  return (
    <div className="h-[600px] w-[320px] bg-background">
      <PropertiesPanel />
    </div>
  );
}
