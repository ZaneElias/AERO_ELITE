import { useState } from "react";
import { AuthDialog } from "../AuthDialog";
import { Button } from "@/components/ui/button";

export default function AuthDialogExample() {
  const [open, setOpen] = useState(true);
  
  return (
    <div className="p-4 bg-background">
      <Button onClick={() => setOpen(true)}>Open Auth Dialog</Button>
      <AuthDialog open={open} onOpenChange={setOpen} />
    </div>
  );
}
