import { useState } from "react";
import { ParameterCard } from "../ParameterCard";

export default function ParameterCardExample() {
  const [value, setValue] = useState(35);
  
  return (
    <div className="p-4 bg-background space-y-2">
      <ParameterCard
        label="Sweep Angle"
        value={value}
        unit="°"
        min={0}
        max={60}
        step={5}
        onChange={setValue}
        testId="param-sweep"
      />
    </div>
  );
}
