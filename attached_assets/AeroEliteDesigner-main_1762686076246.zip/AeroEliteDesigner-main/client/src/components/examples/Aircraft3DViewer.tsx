import { Aircraft3DViewer } from "../Aircraft3DViewer";

export default function Aircraft3DViewerExample() {
  return (
    <div className="h-[600px] w-full">
      <Aircraft3DViewer
        componentType="wing"
        parameters={{ sweep: 35, span: 35, chord: 8 }}
      />
    </div>
  );
}
