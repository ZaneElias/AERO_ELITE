import { Suspense, Component, ErrorInfo, ReactNode, useMemo, useState, useEffect, useRef, useImperativeHandle, forwardRef } from "react";
import { Canvas, useThree, useFrame } from "@react-three/fiber";
import { OrbitControls, Grid } from "@react-three/drei";
import * as THREE from "three";
import { GLTFExporter } from "three/examples/jsm/exporters/GLTFExporter.js";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { AlertCircle, ExternalLink, Download, Eye, Grid3x3, Crosshair } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

function detectWebGLSupport(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    return !!gl;
  } catch (e) {
    return false;
  }
}

function isInIframe(): boolean {
  return window.self !== window.top;
}

function createAirfoilProfile(chordLength: number, thickness: number = 0.12): THREE.Vector2[] {
  const points: THREE.Vector2[] = [];
  const numPoints = 20;
  
  for (let i = 0; i <= numPoints; i++) {
    const x = (i / numPoints) * chordLength;
    const t = i / numPoints;
    
    const yt = 5 * thickness * chordLength * (
      0.2969 * Math.sqrt(t) -
      0.1260 * t -
      0.3516 * t * t +
      0.2843 * t * t * t -
      0.1015 * t * t * t * t
    );
    
    if (i <= numPoints / 2) {
      points.push(new THREE.Vector2(x - chordLength / 2, yt));
    }
  }
  
  for (let i = numPoints / 2; i >= 0; i--) {
    const x = (i / numPoints) * chordLength;
    const t = i / numPoints;
    
    const yt = 5 * thickness * chordLength * (
      0.2969 * Math.sqrt(t) -
      0.1260 * t -
      0.3516 * t * t +
      0.2843 * t * t * t -
      0.1015 * t * t * t * t
    );
    
    points.push(new THREE.Vector2(x - chordLength / 2, -yt));
  }
  
  return points;
}

function createSweptWingGeometry(
  span: number,
  rootChord: number,
  tipChord: number,
  sweep: number
): THREE.BufferGeometry {
  const halfSpan = span / 2;
  const sweepRad = THREE.MathUtils.degToRad(sweep);
  
  const rootProfile = createAirfoilProfile(rootChord, 0.12);
  const tipProfile = createAirfoilProfile(tipChord, 0.10);
  
  const segmentsSpan = 20;
  const segmentsChord = rootProfile.length;
  
  const vertices: number[] = [];
  const indices: number[] = [];
  const normals: number[] = [];
  
  for (let i = 0; i <= segmentsSpan; i++) {
    const spanFraction = i / segmentsSpan;
    const y = -halfSpan + spanFraction * span;
    const sweepOffset = Math.tan(sweepRad) * Math.abs(y);
    
    for (let j = 0; j < segmentsChord; j++) {
      const rootPoint = rootProfile[j];
      const tipPoint = tipProfile[j];
      
      const interpolatedPoint = new THREE.Vector2(
        rootPoint.x * (1 - spanFraction) + tipPoint.x * spanFraction,
        rootPoint.y * (1 - spanFraction) + tipPoint.y * spanFraction
      );
      
      const x = interpolatedPoint.x + sweepOffset;
      const z = interpolatedPoint.y;
      
      vertices.push(x, y, z);
    }
  }
  
  for (let i = 0; i < segmentsSpan; i++) {
    for (let j = 0; j < segmentsChord - 1; j++) {
      const a = i * segmentsChord + j;
      const b = a + segmentsChord;
      const c = a + 1;
      const d = b + 1;
      
      indices.push(a, b, c);
      indices.push(c, b, d);
    }
  }
  
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  
  return geometry;
}

function createFuselageGeometry(length: number, diameter: number): THREE.Group {
  const group = new THREE.Group();
  
  const noseLength = length * 0.15;
  const tailLength = length * 0.25;
  const bodyLength = length - noseLength - tailLength;
  
  const nosePoints: THREE.Vector2[] = [];
  const noseSegments = 20;
  for (let i = 0; i <= noseSegments; i++) {
    const t = i / noseSegments;
    const x = t * noseLength;
    const ellipseT = Math.sqrt(t);
    const r = (diameter / 2) * ellipseT;
    nosePoints.push(new THREE.Vector2(r, x));
  }
  
  const noseGeometry = new THREE.LatheGeometry(nosePoints, 32);
  const noseMesh = new THREE.Mesh(
    noseGeometry,
    new THREE.MeshStandardMaterial({ color: "#78909c", metalness: 0.6, roughness: 0.4 })
  );
  noseMesh.rotation.x = -Math.PI / 2;
  noseMesh.position.set(noseLength / 2, 0, 0);
  noseMesh.castShadow = true;
  group.add(noseMesh);
  
  const bodyGeometry = new THREE.CylinderGeometry(diameter / 2, diameter / 2, bodyLength, 32);
  const bodyMesh = new THREE.Mesh(
    bodyGeometry,
    new THREE.MeshStandardMaterial({ color: "#90a4ae", metalness: 0.6, roughness: 0.4 })
  );
  bodyMesh.rotation.z = Math.PI / 2;
  bodyMesh.position.set(noseLength + bodyLength / 2, 0, 0);
  bodyMesh.castShadow = true;
  group.add(bodyMesh);
  
  const tailPoints: THREE.Vector2[] = [];
  const tailSegments = 20;
  for (let i = 0; i <= tailSegments; i++) {
    const t = i / tailSegments;
    const x = t * tailLength;
    const r = (diameter / 2) * (1 - Math.pow(t, 1.5));
    tailPoints.push(new THREE.Vector2(r, x));
  }
  
  const tailGeometry = new THREE.LatheGeometry(tailPoints, 32);
  const tailMesh = new THREE.Mesh(
    tailGeometry,
    new THREE.MeshStandardMaterial({ color: "#78909c", metalness: 0.6, roughness: 0.4 })
  );
  tailMesh.rotation.x = -Math.PI / 2;
  tailMesh.position.set(noseLength + bodyLength + tailLength / 2, 0, 0);
  tailMesh.castShadow = true;
  group.add(tailMesh);
  
  return group;
}

function WingModel({ sweep = 35, span = 35, chord = 8 }: { sweep?: number; span?: number; chord?: number }) {
  const geometry = useMemo(() => {
    const rootChord = chord;
    const tipChord = chord * 0.6;
    return createSweptWingGeometry(span, rootChord, tipChord, sweep);
  }, [sweep, span, chord]);
  
  return (
    <mesh geometry={geometry} castShadow receiveShadow>
      <meshStandardMaterial color="#607d8b" metalness={0.7} roughness={0.3} />
    </mesh>
  );
}

function FuselageModel({ length = 40, diameter = 4 }: { length?: number; diameter?: number }) {
  const fuselageGroup = useMemo(() => {
    return createFuselageGeometry(length, diameter);
  }, [length, diameter]);
  
  return <primitive object={fuselageGroup} />;
}

function VerticalStabilizer({ height = 6, chord = 5 }: { height?: number; chord?: number }) {
  const geometry = useMemo(() => {
    const rootChord = chord;
    const tipChord = chord * 0.5;
    return createSweptWingGeometry(height, rootChord, tipChord, 40);
  }, [height, chord]);
  
  return (
    <mesh geometry={geometry} rotation={[0, 0, Math.PI / 2]} castShadow>
      <meshStandardMaterial color="#546e7a" metalness={0.7} roughness={0.3} />
    </mesh>
  );
}

function HorizontalStabilizer({ span = 12, chord = 4 }: { span?: number; chord?: number }) {
  const geometry = useMemo(() => {
    const rootChord = chord;
    const tipChord = chord * 0.6;
    return createSweptWingGeometry(span, rootChord, tipChord, 25);
  }, [span, chord]);
  
  return (
    <mesh geometry={geometry} castShadow>
      <meshStandardMaterial color="#546e7a" metalness={0.7} roughness={0.3} />
    </mesh>
  );
}

function EngineNacelle({ position, length = 4, diameter = 1.5 }: { position: [number, number, number]; length?: number; diameter?: number }) {
  return (
    <group position={position}>
      <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
        <cylinderGeometry args={[diameter / 2, diameter / 2, length, 16]} />
        <meshStandardMaterial color="#455a64" metalness={0.8} roughness={0.2} />
      </mesh>
      <mesh position={[-length / 2 - 0.3, 0, 0]} rotation={[0, 0, -Math.PI / 2]}>
        <coneGeometry args={[diameter / 2 + 0.1, 0.6, 16]} />
        <meshStandardMaterial color="#37474f" metalness={0.9} roughness={0.1} />
      </mesh>
      <mesh position={[length / 2, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[diameter / 2 - 0.2, diameter / 2, length * 0.3, 16]} />
        <meshStandardMaterial color="#263238" metalness={0.8} roughness={0.3} />
      </mesh>
    </group>
  );
}

interface Aircraft3DViewerProps {
  componentType?: "wing" | "fuselage" | "complete";
  parameters?: {
    sweep?: number;
    span?: number;
    chord?: number;
    length?: number;
    diameter?: number;
  };
}

export interface Aircraft3DViewerRef {
  exportModel: () => void;
  setCameraPosition: (position: [number, number, number]) => void;
  resetCamera: () => void;
  toggleGrid: () => void;
}

function SceneRef({ onSceneReady }: { onSceneReady: (scene: THREE.Scene) => void }) {
  const { scene } = useThree();
  
  useEffect(() => {
    onSceneReady(scene);
  }, [scene, onSceneReady]);
  
  return null;
}

function CameraTracker({ onCameraUpdate }: { onCameraUpdate: (position: THREE.Vector3, distance: number) => void }) {
  const { camera } = useThree();
  
  useFrame(() => {
    const distance = camera.position.length();
    onCameraUpdate(camera.position, distance);
  });
  
  return null;
}

function ViewportHUD({ gridEnabled, viewMode, cameraPosition, cameraDistance }: { 
  gridEnabled: boolean; 
  viewMode: string;
  cameraPosition: THREE.Vector3 | null;
  cameraDistance: number;
}) {
  return (
    <Card className="absolute bottom-4 left-4 p-3 bg-card/80 backdrop-blur-sm border-border/50 space-y-2 min-w-[200px]" data-testid="viewport-hud">
      <div className="flex items-center gap-2 text-xs">
        <Eye className="h-3 w-3 text-muted-foreground" />
        <span className="text-muted-foreground">View:</span>
        <Badge variant="secondary" className="text-xs font-mono" data-testid="hud-view-mode">
          {viewMode}
        </Badge>
      </div>
      
      <div className="flex items-center gap-2 text-xs">
        <Grid3x3 className="h-3 w-3 text-muted-foreground" />
        <span className="text-muted-foreground">Grid:</span>
        <Badge 
          variant={gridEnabled ? "default" : "secondary"} 
          className="text-xs font-mono"
          data-testid="hud-grid-status"
        >
          {gridEnabled ? "ON" : "OFF"}
        </Badge>
      </div>
      
      {cameraPosition && (
        <div className="flex items-center gap-2 text-xs">
          <Crosshair className="h-3 w-3 text-muted-foreground" />
          <span className="text-muted-foreground">Dist:</span>
          <span className="font-mono text-foreground" data-testid="hud-camera-distance">
            {cameraDistance.toFixed(1)}m
          </span>
        </div>
      )}
    </Card>
  );
}

function CameraController({ 
  targetPosition, 
  onAnimationComplete 
}: { 
  targetPosition: [number, number, number] | null;
  onAnimationComplete: () => void;
}) {
  const { camera } = useThree();
  
  useFrame(() => {
    if (targetPosition) {
      const target = new THREE.Vector3(...targetPosition);
      camera.position.lerp(target, 0.1);
      
      if (camera.position.distanceTo(target) < 0.1) {
        camera.position.copy(target);
        onAnimationComplete();
      }
    }
  });
  
  return null;
}

function Scene({ 
  componentType = "wing", 
  parameters = {}, 
  onSceneReady, 
  onCameraUpdate,
  targetCameraPosition,
  onCameraAnimationComplete,
  gridVisible = true
}: Aircraft3DViewerProps & { 
  onSceneReady?: (scene: THREE.Scene) => void;
  onCameraUpdate?: (position: THREE.Vector3, distance: number) => void;
  targetCameraPosition?: [number, number, number] | null;
  onCameraAnimationComplete?: () => void;
  gridVisible?: boolean;
}) {
  const {
    sweep = 35,
    span = 35,
    chord = 8,
    length = 40,
    diameter = 4
  } = parameters;
  
  return (
    <>
      {onSceneReady && <SceneRef onSceneReady={onSceneReady} />}
      {onCameraUpdate && <CameraTracker onCameraUpdate={onCameraUpdate} />}
      {targetCameraPosition && onCameraAnimationComplete && (
        <CameraController 
          targetPosition={targetCameraPosition}
          onAnimationComplete={onCameraAnimationComplete}
        />
      )}
      
      <color attach="background" args={["#0a0f14"]} />
      
      <ambientLight intensity={0.5} />
      <directionalLight
        position={[10, 20, 10]}
        intensity={1}
        castShadow
      />
      <pointLight position={[-10, 10, -10]} intensity={0.5} />
      <hemisphereLight args={["#ffffff", "#3d5a80", 0.3]} />
      
      {gridVisible && <Grid args={[200, 200]} cellSize={5} cellThickness={0.5} cellColor="#3d5a80" sectionSize={20} sectionThickness={1} sectionColor="#4a6fa5" fadeDistance={400} fadeStrength={1} infiniteGrid={false} />}
      
      {componentType === "wing" && (
        <group>
          <WingModel sweep={sweep} span={span} chord={chord} />
          <EngineNacelle position={[-chord * 0.3, -span * 0.3, -1.5]} />
          <EngineNacelle position={[-chord * 0.3, span * 0.3, -1.5]} />
        </group>
      )}
      
      {componentType === "fuselage" && (
        <FuselageModel length={length} diameter={diameter} />
      )}
      
      {componentType === "complete" && (
        <group>
          <FuselageModel length={length} diameter={diameter} />
          
          <group position={[length * 0.2, 0, 0]}>
            <WingModel sweep={sweep} span={span} chord={chord} />
            <EngineNacelle position={[-chord * 0.3, -span * 0.3, -diameter * 0.6]} />
            <EngineNacelle position={[-chord * 0.3, span * 0.3, -diameter * 0.6]} />
          </group>
          
          <group position={[length * 0.85, 0, diameter * 0.5]}>
            <HorizontalStabilizer span={span * 0.35} chord={chord * 0.5} />
          </group>
          
          <group position={[length * 0.85, 0, 0]}>
            <VerticalStabilizer height={diameter * 2} chord={chord * 0.6} />
          </group>
        </group>
      )}
      
      <OrbitControls
        enableDamping
        dampingFactor={0.05}
        minDistance={20}
        maxDistance={200}
      />
    </>
  );
}

class ErrorBoundary extends Component<
  { children: ReactNode; fallback: ReactNode },
  { hasError: boolean; error: Error | null }
> {
  constructor(props: { children: ReactNode; fallback: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("3D Viewer Error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }

    return this.props.children;
  }
}

export const Aircraft3DViewer = forwardRef<Aircraft3DViewerRef, Aircraft3DViewerProps>(
  ({ componentType = "wing", parameters = {} }, ref) => {
    const [webGLSupported, setWebGLSupported] = useState<boolean>(true);
    const [inIframe, setInIframe] = useState<boolean>(false);
    const [isExporting, setIsExporting] = useState<boolean>(false);
    const [cameraPosition, setCameraPosition] = useState<THREE.Vector3 | null>(null);
    const [cameraDistance, setCameraDistance] = useState<number>(0);
    const [gridEnabled, setGridEnabled] = useState<boolean>(true);
    const [viewMode] = useState<string>("Perspective");
    const [targetCameraPosition, setTargetCameraPosition] = useState<[number, number, number] | null>(null);
    const sceneRef = useRef<THREE.Scene | null>(null);
    const { toast } = useToast();
    
    const handleCameraUpdate = (position: THREE.Vector3, distance: number) => {
      setCameraPosition(position);
      setCameraDistance(distance);
    };
    
    const handleSetCameraPosition = (position: [number, number, number]) => {
      setTargetCameraPosition(position);
    };
    
    const handleResetCamera = () => {
      setTargetCameraPosition([50, 30, 50]);
    };
    
    const handleToggleGrid = () => {
      setGridEnabled(prev => !prev);
    };
    
    const handleCameraAnimationComplete = () => {
      setTargetCameraPosition(null);
    };
    
    useEffect(() => {
      setWebGLSupported(detectWebGLSupport());
      setInIframe(isInIframe());
    }, []);
    
    const handleSceneReady = (scene: THREE.Scene) => {
      sceneRef.current = scene;
    };
    
    const exportModel = async () => {
      if (!sceneRef.current) {
        toast({
          title: "Export Failed",
          description: "3D scene is not ready yet. Please wait for the model to load.",
          variant: "destructive",
        });
        return;
      }
      
      setIsExporting(true);
      toast({
        title: "Exporting Model",
        description: "Preparing your 3D model for download...",
      });
      
      try {
        const exporter = new GLTFExporter();
        
        const result = await new Promise<ArrayBuffer>((resolve, reject) => {
          exporter.parse(
            sceneRef.current!,
            (gltf) => {
              resolve(gltf as ArrayBuffer);
            },
            (error) => {
              reject(error);
            },
            { binary: true }
          );
        });
        
        const blob = new Blob([result], { type: 'application/octet-stream' });
        const url = URL.createObjectURL(blob);
        
        const filename = generateFilename(componentType, parameters);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        URL.revokeObjectURL(url);
        
        toast({
          title: "Export Complete",
          description: `Model saved as ${filename}`,
        });
      } catch (error) {
        console.error("Export error:", error);
        toast({
          title: "Export Failed",
          description: "Failed to export the 3D model. Please try again.",
          variant: "destructive",
        });
      } finally {
        setIsExporting(false);
      }
    };
    
    useImperativeHandle(ref, () => ({
      exportModel,
      setCameraPosition: handleSetCameraPosition,
      resetCamera: handleResetCamera,
      toggleGrid: handleToggleGrid,
    }));
    
    const openInNewTab = () => {
      window.open(window.location.href, '_blank');
    };
    
    if (!webGLSupported) {
      return (
        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-background to-muted/20 p-8">
          <Alert className="max-w-md">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>WebGL Not Supported</AlertTitle>
            <AlertDescription className="space-y-4">
              <p>
                Your browser or environment doesn't support WebGL, which is required for the 3D viewer.
              </p>
              {inIframe && (
                <Button 
                  onClick={openInNewTab} 
                  variant="outline" 
                  className="w-full"
                  data-testid="button-open-new-tab"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Open in New Tab
                </Button>
              )}
            </AlertDescription>
          </Alert>
        </div>
      );
    }
    
    const fallbackUI = (
      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-background to-muted/20 p-8">
        <Alert className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>3D Viewer Error</AlertTitle>
          <AlertDescription className="space-y-4">
            <p>
              The 3D viewer encountered an error and could not initialize properly.
            </p>
            {inIframe && (
              <>
                <p className="text-sm text-muted-foreground">
                  Try opening this page in a new tab for better WebGL performance.
                </p>
                <Button 
                  onClick={openInNewTab} 
                  variant="outline" 
                  className="w-full"
                  data-testid="button-open-new-tab"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Open in New Tab
                </Button>
              </>
            )}
            <p className="text-sm text-muted-foreground">
              You can still use the AI parameter extraction feature.
            </p>
          </AlertDescription>
        </Alert>
      </div>
    );

    return (
      <div className="w-full h-full bg-gradient-to-br from-background to-muted/20 relative">
        <Button
          onClick={exportModel}
          disabled={isExporting}
          variant="default"
          size="sm"
          className="absolute top-20 right-4 z-10"
          data-testid="button-download-model"
        >
          <Download className="h-4 w-4 mr-2" />
          {isExporting ? "Exporting..." : "Download GLB"}
        </Button>
        
        <ViewportHUD
          gridEnabled={gridEnabled}
          viewMode={viewMode}
          cameraPosition={cameraPosition}
          cameraDistance={cameraDistance}
        />
        
        <ErrorBoundary fallback={fallbackUI}>
          <Suspense
            fallback={
              <div className="w-full h-full flex items-center justify-center">
                <div className="text-muted-foreground">Loading 3D model...</div>
              </div>
            }
          >
            <Canvas
              camera={{ position: [50, 30, 50], fov: 50 }}
              shadows
              gl={{ antialias: true }}
            >
              <Scene 
                componentType={componentType} 
                parameters={parameters}
                onSceneReady={handleSceneReady}
                onCameraUpdate={handleCameraUpdate}
                targetCameraPosition={targetCameraPosition}
                onCameraAnimationComplete={handleCameraAnimationComplete}
                gridVisible={gridEnabled}
              />
            </Canvas>
          </Suspense>
        </ErrorBoundary>
      </div>
    );
  }
);

Aircraft3DViewer.displayName = "Aircraft3DViewer";

function generateFilename(
  componentType: "wing" | "fuselage" | "complete",
  parameters: Aircraft3DViewerProps["parameters"]
): string {
  const {
    sweep = 35,
    span = 35,
    chord = 8,
    length = 40,
    diameter = 4,
  } = parameters || {};
  
  const timestamp = new Date().toISOString().split('T')[0];
  
  if (componentType === "wing") {
    return `aircraft-wing-sweep${sweep}deg-span${span}m-${timestamp}.glb`;
  } else if (componentType === "fuselage") {
    return `aircraft-fuselage-length${length}m-dia${diameter}m-${timestamp}.glb`;
  } else {
    return `aircraft-complete-${timestamp}.glb`;
  }
}
