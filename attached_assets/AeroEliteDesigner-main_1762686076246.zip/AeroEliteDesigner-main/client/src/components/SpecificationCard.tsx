import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface SpecificationCardProps {
  icon: LucideIcon;
  label: string;
  value: string | number;
  unit?: string;
  testId?: string;
}

export function SpecificationCard({
  icon: Icon,
  label,
  value,
  unit,
  testId,
}: SpecificationCardProps) {
  return (
    <Card className="p-4" data-testid={testId}>
      <div className="flex items-start gap-3">
        <div className="p-2 rounded-md bg-primary/10">
          <Icon className="h-5 w-5 text-primary" />
        </div>
        <div className="flex-1">
          <p className="text-sm text-muted-foreground mb-1">{label}</p>
          <p className="text-2xl font-semibold font-mono" data-testid={`${testId}-value`}>
            {value}
            {unit && <span className="text-base ml-1 text-muted-foreground">{unit}</span>}
          </p>
        </div>
      </div>
    </Card>
  );
}
