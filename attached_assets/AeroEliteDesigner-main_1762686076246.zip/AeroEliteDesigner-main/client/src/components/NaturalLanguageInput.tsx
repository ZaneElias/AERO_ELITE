import { useState } from "react";
import { Sparkles, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import type { AircraftParameters } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

const examplePrompts = [
  "Left wing with 35° sweep, 35m span, carbon composite",
  "Fuselage 40m length, 4m diameter, aluminum alloy",
  "Twin turbofan engines, 50kN thrust each",
];

interface NaturalLanguageInputProps {
  onParametersExtracted?: (parameters: AircraftParameters, explanation: string, prompt: string) => void;
}

export function NaturalLanguageInput({ onParametersExtracted }: NaturalLanguageInputProps) {
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    
    try {
      const response = await apiRequest("POST", "/api/extract-parameters", { prompt });
      const data = await response.json();
      
      if (response.ok) {
        onParametersExtracted?.(data.parameters, data.explanation, prompt);
        toast({
          title: "Parameters Extracted",
          description: "AI successfully analyzed your description",
        });
      } else {
        throw new Error(data.error || "Failed to extract parameters");
      }
    } catch (error) {
      console.error("Error extracting parameters:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to process your description",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleExampleClick = (example: string) => {
    setPrompt(example);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 mb-2">
        <Sparkles className="h-4 w-4 text-primary" />
        <span className="text-sm font-medium">AI Component Generator</span>
      </div>
      
      <Textarea
        placeholder="Describe your aircraft component... (e.g., 'Generate a left wing with 35° sweep angle, 35m wingspan, carbon composite skeleton')"
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        className="min-h-[100px] resize-none"
        data-testid="input-prompt"
      />
      
      <div className="flex flex-wrap gap-2">
        {examplePrompts.map((example, i) => (
          <Badge
            key={i}
            variant="secondary"
            className="cursor-pointer text-xs hover-elevate active-elevate-2"
            onClick={() => handleExampleClick(example)}
            data-testid={`badge-example-${i}`}
          >
            {example}
          </Badge>
        ))}
      </div>
      
      <Button
        onClick={handleGenerate}
        disabled={!prompt.trim() || isGenerating}
        className="w-full"
        data-testid="button-generate"
      >
        {isGenerating ? (
          <>
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            Generating...
          </>
        ) : (
          <>
            <Sparkles className="h-4 w-4 mr-2" />
            Generate 3D Model
          </>
        )}
      </Button>
      
      <div className="text-xs text-muted-foreground">
        {prompt.length}/500 characters
      </div>
    </div>
  );
}
