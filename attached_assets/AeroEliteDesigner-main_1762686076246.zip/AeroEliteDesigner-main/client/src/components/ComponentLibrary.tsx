import { useQuery } from "@tanstack/react-query";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Plane, CircleDot, Save, Loader2, Rocket, Building } from "lucide-react";
import type { AircraftDesign, AircraftTemplate } from "@shared/schema";

interface ComponentLibraryProps {
  onLoadDesign?: (design: AircraftDesign) => void;
}

export function ComponentLibrary({ onLoadDesign }: ComponentLibraryProps) {
  const { data: savedDesigns, isLoading: loadingDesigns } = useQuery<AircraftDesign[]>({
    queryKey: ["/api/designs"],
  });
  
  const { data: templates, isLoading: loadingTemplates } = useQuery<AircraftTemplate[]>({
    queryKey: ["/api/templates"],
  });

  const designCount = Array.isArray(savedDesigns) ? savedDesigns.length : 0;
  const templateCount = Array.isArray(templates) ? templates.length : 0;
  
  // Group templates by category
  const groupedTemplates = templates?.reduce((acc, template) => {
    if (!acc[template.category]) {
      acc[template.category] = [];
    }
    acc[template.category].push(template);
    return acc;
  }, {} as Record<string, AircraftTemplate[]>) || {};
  
  const handleLoadTemplate = (template: AircraftTemplate) => {
    // Convert template to AircraftDesign format for the viewer
    const designFromTemplate: AircraftDesign = {
      id: template.id,
      userId: null,
      name: template.name,
      description: template.description,
      componentType: template.componentType,
      parameters: template.parameters,
      prompt: `Template: ${template.name}`,
      createdAt: template.createdAt,
      updatedAt: template.createdAt,
    };
    onLoadDesign?.(designFromTemplate);
  };
  
  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'military': return Rocket;
      case 'commercial': return Building;
      case 'components': return CircleDot;
      default: return Plane;
    }
  };

  return (
    <div className="p-4 space-y-2">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-medium text-sm">Component Library</h3>
        <Badge variant="secondary" className="text-xs">
          {templateCount} Templates
        </Badge>
      </div>

      <Accordion type="single" collapsible defaultValue="saved">
        {/* Saved Designs Section */}
        <AccordionItem value="saved">
          <AccordionTrigger className="text-sm py-2">
            <div className="flex items-center gap-2">
              <Save className="h-4 w-4" />
              Saved Designs
              {designCount > 0 && (
                <Badge variant="secondary" className="ml-auto text-xs">
                  {designCount}
                </Badge>
              )}
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-1 pl-6">
              {loadingDesigns ? (
                <div className="flex items-center justify-center py-4 text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Loading...
                </div>
              ) : designCount === 0 ? (
                <div className="py-4 text-sm text-muted-foreground text-center">
                  No saved designs yet
                </div>
              ) : (
                savedDesigns?.map((design) => (
                  <Button
                    key={design.id}
                    variant="ghost"
                    className="w-full justify-start text-sm h-auto py-2"
                    onClick={() => onLoadDesign?.(design)}
                    data-testid={`button-design-${design.id}`}
                  >
                    <div className="text-left">
                      <div className="font-medium">{design.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {design.description || `${design.componentType} · ${new Date(design.createdAt).toLocaleDateString()}`}
                      </div>
                    </div>
                  </Button>
                ))
              )}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Aircraft Templates from Database */}
        {loadingTemplates ? (
          <div className="flex items-center justify-center py-8 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin mr-2" />
            Loading templates...
          </div>
        ) : (
          Object.entries(groupedTemplates).map(([category, categoryTemplates]) => {
            const CategoryIcon = getCategoryIcon(category);
            return (
              <AccordionItem key={category} value={category}>
                <AccordionTrigger className="text-sm py-2">
                  <div className="flex items-center gap-2">
                    <CategoryIcon className="h-4 w-4" />
                    {category}
                    <Badge variant="secondary" className="ml-auto text-xs">
                      {categoryTemplates.length}
                    </Badge>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-1 pl-6">
                    {categoryTemplates.map((template) => (
                      <Button
                        key={template.id}
                        variant="ghost"
                        className="w-full justify-start text-sm h-auto py-2"
                        onClick={() => handleLoadTemplate(template)}
                        data-testid={`button-template-${template.id}`}
                      >
                        <div className="text-left">
                          <div className="font-medium">{template.name}</div>
                          <div className="text-xs text-muted-foreground line-clamp-2">
                            {template.description}
                          </div>
                        </div>
                      </Button>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            );
          })
        )}
      </Accordion>
    </div>
  );
}
