import { useState, useRef, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, Loader2, ExternalLink, AlertCircle } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface MeshyGeneratorProps {
  onMeshGenerated?: (taskId: string, modelUrl: string) => void;
}

const MESHY_PAID_PLAN_KEY = "meshyPaidPlanEnabled";

export function MeshyGenerator({ onMeshGenerated }: MeshyGeneratorProps) {
  const [showWarning, setShowWarning] = useState(false);
  const [open, setOpen] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [negativePrompt, setNegativePrompt] = useState("low quality, low resolution, ugly");
  const [artStyle, setArtStyle] = useState<string>("realistic");
  const [taskId, setTaskId] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<string>("");
  const [hasPaidPlan, setHasPaidPlan] = useState(() => {
    return localStorage.getItem(MESHY_PAID_PLAN_KEY) === "true";
  });
  const { toast } = useToast();
  const pollingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Cleanup polling on unmount or dialog close
  useEffect(() => {
    return () => {
      if (pollingTimeoutRef.current) {
        clearTimeout(pollingTimeoutRef.current);
        pollingTimeoutRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!open) {
      // Clear polling when dialog closes
      if (pollingTimeoutRef.current) {
        clearTimeout(pollingTimeoutRef.current);
        pollingTimeoutRef.current = null;
      }
    }
  }, [open]);

  const createPreviewMutation = useMutation({
    mutationFn: async (data: { prompt: string; negativePrompt?: string; artStyle?: string }) => {
      const response = await apiRequest("POST", "/api/meshy/preview", {
        prompt: data.prompt,
        negativePrompt: data.negativePrompt,
        artStyle: data.artStyle,
        shouldRemesh: true,
        enablePbr: true,
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        
        if (response.status === 402) {
          const error = new Error("PAYMENT_REQUIRED");
          (error as any).status = 402;
          throw error;
        }
        
        const errorMsg = errorData.error 
          ? `Meshy API error (${response.status}): ${errorData.error}`
          : `Meshy API error (${response.status})`;
        throw new Error(errorMsg);
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      setTaskId(data.taskId);
      setStatus("IN_PROGRESS");
      pollTaskStatus(data.taskId);
      toast({
        title: "Generation Started",
        description: "Your 3D model is being generated. This may take a few minutes.",
      });
    },
    onError: (error) => {
      if ((error as any).status === 402 || error.message === "PAYMENT_REQUIRED") {
        toast({
          title: "Paid Subscription Required",
          description: (
            <div className="space-y-2">
              <p>Meshy requires a paid subscription (~$16/month) to generate 3D models.</p>
              <a 
                href="https://www.meshy.ai/settings/subscription" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:underline inline-flex items-center gap-1"
              >
                Upgrade at meshy.ai <ExternalLink className="h-3 w-3" />
              </a>
              <p className="text-xs text-muted-foreground">Or use the free parametric generator instead!</p>
            </div>
          ),
          variant: "destructive",
        });
        
        localStorage.setItem(MESHY_PAID_PLAN_KEY, "false");
        setHasPaidPlan(false);
        setOpen(false);
      } else {
        toast({
          title: "Generation Failed",
          description: error instanceof Error ? error.message : "Failed to start generation",
          variant: "destructive",
        });
      }
    },
  });

  const pollTaskStatus = async (id: string) => {
    // Clear any existing timeout
    if (pollingTimeoutRef.current) {
      clearTimeout(pollingTimeoutRef.current);
      pollingTimeoutRef.current = null;
    }

    const poll = async () => {
      try {
        const response = await apiRequest("GET", `/api/meshy/task/${id}`, null);
        
        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(errorData.error || `HTTP ${response.status}: Failed to fetch task status`);
        }
        
        const data = await response.json();
        setProgress(data.progress || 0);
        setStatus(data.status);
        
        if (data.status === "SUCCEEDED") {
          toast({
            title: "Model Generated!",
            description: "Your 3D aircraft model is ready",
          });
          
          if (data.model_urls?.glb) {
            onMeshGenerated?.(id, data.model_urls.glb);
          }
          
          setOpen(false);
          resetForm();
          pollingTimeoutRef.current = null;
        } else if (data.status === "FAILED") {
          toast({
            title: "Generation Failed",
            description: data.error || "The model generation failed",
            variant: "destructive",
          });
          resetForm();
          pollingTimeoutRef.current = null;
        } else {
          // Continue polling - store timeout ref for cleanup
          pollingTimeoutRef.current = setTimeout(poll, 3000);
        }
      } catch (error) {
        console.error("Error polling task status:", error);
        
        // Clear timeout and reset state on error
        if (pollingTimeoutRef.current) {
          clearTimeout(pollingTimeoutRef.current);
          pollingTimeoutRef.current = null;
        }
        
        resetForm();
        
        toast({
          title: "Status Check Failed",
          description: error instanceof Error ? error.message : "Failed to check generation status. Please try again.",
          variant: "destructive",
        });
      }
    };
    
    poll();
  };

  const resetForm = () => {
    setPrompt("");
    setNegativePrompt("low quality, low resolution, ugly");
    setArtStyle("realistic");
    setTaskId(null);
    setProgress(0);
    setStatus("");
  };

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt Required",
        description: "Please enter a description for your 3D model",
        variant: "destructive",
      });
      return;
    }
    
    createPreviewMutation.mutate({
      prompt,
      negativePrompt,
      artStyle,
    });
  };

  const handleButtonClick = () => {
    if (!hasPaidPlan) {
      setShowWarning(true);
    } else {
      setOpen(true);
    }
  };

  const handleConfirmPaidPlan = () => {
    localStorage.setItem(MESHY_PAID_PLAN_KEY, "true");
    setHasPaidPlan(true);
    setShowWarning(false);
    setOpen(true);
  };

  const handleCancelWarning = () => {
    setShowWarning(false);
  };

  const isGenerating = status === "IN_PROGRESS" || status === "PENDING";

  return (
    <>
      <AlertDialog open={showWarning} onOpenChange={setShowWarning}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-yellow-600" />
              Meshy AI - Paid Service Required
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-3 pt-2">
              <p className="text-base">
                <strong>Meshy is a paid third-party service</strong> that requires a subscription of approximately <strong>$16/month</strong>.
              </p>
              
              <div className="bg-muted p-3 rounded-md space-y-2">
                <p className="text-sm font-medium text-foreground">Before you continue:</p>
                <ul className="text-sm space-y-1 list-disc list-inside">
                  <li>You must have an active Meshy subscription</li>
                  <li>Upgrade at <a 
                    href="https://www.meshy.ai/settings/subscription" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary hover:underline inline-flex items-center gap-1"
                  >
                    meshy.ai/settings/subscription <ExternalLink className="h-3 w-3" />
                  </a></li>
                </ul>
              </div>

              <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 p-3 rounded-md">
                <p className="text-sm font-medium text-green-900 dark:text-green-100 mb-1">
                  Free Alternative Available!
                </p>
                <p className="text-sm text-green-800 dark:text-green-200">
                  The <strong>parametric generator</strong> above is completely free and works great for aircraft design.
                </p>
              </div>

              <p className="text-sm text-muted-foreground">
                Only click "I Have a Paid Plan" if you've already subscribed to Meshy.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={handleCancelWarning} data-testid="button-cancel-warning">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmPaidPlan} data-testid="button-confirm-paid-plan">
              I Have a Paid Plan
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>Generate 3D Model with AI</DialogTitle>
            <DialogDescription>
              Create a realistic 3D aircraft model using Meshy AI. Describe what you want to generate.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="mesh-prompt">Model Description *</Label>
              <Textarea
                id="mesh-prompt"
                placeholder="e.g., A sleek modern fighter jet with swept wings and afterburners"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                disabled={isGenerating}
                rows={3}
                data-testid="textarea-mesh-prompt"
              />
              <p className="text-xs text-muted-foreground">
                Max 600 characters. Be specific for best results.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="art-style">Art Style</Label>
              <Select
                value={artStyle}
                onValueChange={setArtStyle}
                disabled={isGenerating}
              >
                <SelectTrigger id="art-style" data-testid="select-art-style">
                  <SelectValue placeholder="Select art style" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="realistic">Realistic</SelectItem>
                  <SelectItem value="cartoon">Cartoon</SelectItem>
                  <SelectItem value="low-poly">Low Poly</SelectItem>
                  <SelectItem value="sculpture">Sculpture</SelectItem>
                  <SelectItem value="pbr">PBR</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="negative-prompt">Negative Prompt (Optional)</Label>
              <Textarea
                id="negative-prompt"
                placeholder="What to avoid in the generation"
                value={negativePrompt}
                onChange={(e) => setNegativePrompt(e.target.value)}
                disabled={isGenerating}
                rows={2}
                data-testid="textarea-negative-prompt"
              />
            </div>

            {isGenerating && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Generating...</span>
                  <span>{progress}%</span>
                </div>
                <Progress value={progress} className="w-full" />
              </div>
            )}
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setOpen(false)}
              disabled={isGenerating}
              data-testid="button-cancel-mesh"
            >
              Cancel
            </Button>
            <Button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              data-testid="button-generate-mesh"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Generate Model
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Button 
        variant="outline" 
        className="w-full" 
        onClick={handleButtonClick}
        data-testid="button-meshy-generate"
      >
        <Sparkles className="h-4 w-4 mr-2" />
        Generate with AI (Meshy)
      </Button>
    </>
  );
}
