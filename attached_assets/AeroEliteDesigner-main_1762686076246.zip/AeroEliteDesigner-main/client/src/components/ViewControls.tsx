import { RefObject } from "react";
import { Button } from "@/components/ui/button";
import {
  Camera,
  Grid3x3,
  Maximize2,
  Box,
  ChevronUp,
  ChevronRight,
  Orbit,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import type { Aircraft3DViewerRef } from "./Aircraft3DViewer";

interface ViewPreset {
  name: string;
  icon: typeof Box;
  position: [number, number, number];
  tooltip: string;
}

const viewPresets: ViewPreset[] = [
  { name: "Top", icon: ChevronUp, position: [0, 100, 0], tooltip: "Top View (Y+)" },
  { name: "Front", icon: Box, position: [0, 0, 100], tooltip: "Front View (Z+)" },
  { name: "Right", icon: ChevronRight, position: [100, 0, 0], tooltip: "Right View (X+)" },
  { name: "Iso", icon: Orbit, position: [50, 50, 50], tooltip: "Isometric View" },
];

interface ViewControlsProps {
  viewerRef?: RefObject<Aircraft3DViewerRef>;
}

export function ViewControls({ viewerRef }: ViewControlsProps) {
  const handleViewPreset = (position: [number, number, number]) => {
    viewerRef?.current?.setCameraPosition(position);
  };
  
  const handleToggleGrid = () => {
    viewerRef?.current?.toggleGrid();
  };
  
  const handleResetCamera = () => {
    viewerRef?.current?.resetCamera();
  };
  
  const handleFullscreen = () => {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      document.documentElement.requestFullscreen();
    }
  };

  return (
    <TooltipProvider>
      <Card className="absolute top-4 right-4 p-2 space-y-2 bg-card/80 backdrop-blur-sm border-border/50" data-testid="view-controls">
        <div className="flex gap-1">
          {viewPresets.map((preset) => (
            <Tooltip key={preset.name}>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 px-2 text-xs hover-elevate"
                  onClick={() => handleViewPreset(preset.position)}
                  data-testid={`button-view-${preset.name.toLowerCase()}`}
                >
                  <preset.icon className="h-3 w-3 mr-1" />
                  {preset.name}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{preset.tooltip}</p>
              </TooltipContent>
            </Tooltip>
          ))}
        </div>
        
        <Separator />
        
        <div className="flex gap-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={handleToggleGrid}
                data-testid="button-toggle-grid"
              >
                <Grid3x3 className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Toggle Grid</p>
            </TooltipContent>
          </Tooltip>
          
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={handleResetCamera}
                data-testid="button-reset-camera"
              >
                <Camera className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Reset Camera</p>
            </TooltipContent>
          </Tooltip>
          
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={handleFullscreen}
                data-testid="button-fullscreen"
              >
                <Maximize2 className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Toggle Fullscreen</p>
            </TooltipContent>
          </Tooltip>
        </div>
      </Card>
    </TooltipProvider>
  );
}
