import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ChevronUp, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ParameterCardProps {
  label: string;
  value: number;
  unit: string;
  min?: number;
  max?: number;
  step?: number;
  onChange?: (value: number) => void;
  testId?: string;
}

export function ParameterCard({
  label,
  value,
  unit,
  min = 0,
  max = 100,
  step = 1,
  onChange,
  testId,
}: ParameterCardProps) {
  const handleIncrement = () => {
    const newValue = Math.min(value + step, max);
    onChange?.(newValue);
  };

  const handleDecrement = () => {
    const newValue = Math.max(value - step, min);
    onChange?.(newValue);
  };

  return (
    <div className="grid grid-cols-[120px_1fr_60px_auto] gap-2 items-center p-2 rounded-md hover-elevate">
      <Label className="text-sm font-medium">{label}</Label>
      <Input
        type="number"
        value={value}
        onChange={(e) => onChange?.(parseFloat(e.target.value) || 0)}
        min={min}
        max={max}
        step={step}
        className="h-9"
        data-testid={testId}
      />
      <span className="text-sm text-muted-foreground font-mono">{unit}</span>
      <div className="flex flex-col gap-0">
        <Button
          variant="ghost"
          size="icon"
          className="h-4 w-6 p-0"
          onClick={handleIncrement}
          data-testid={`${testId}-increment`}
        >
          <ChevronUp className="h-3 w-3" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-4 w-6 p-0"
          onClick={handleDecrement}
          data-testid={`${testId}-decrement`}
        >
          <ChevronDown className="h-3 w-3" />
        </Button>
      </div>
    </div>
  );
}
