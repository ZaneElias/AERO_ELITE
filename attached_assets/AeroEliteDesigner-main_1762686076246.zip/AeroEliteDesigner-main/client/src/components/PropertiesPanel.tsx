import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ParameterCard } from "./ParameterCard";
import { SpecificationCard } from "./SpecificationCard";
import { Button } from "@/components/ui/button";
import { Download, Save, Ruler, Weight, Layers, Palette, FileDown, Settings } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { AircraftParameters } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface PropertiesPanelProps {
  componentType?: "wing" | "fuselage" | "complete";
  parameters?: {
    sweep?: number;
    span?: number;
    chord?: number;
    length?: number;
    diameter?: number;
  };
  lastPrompt?: string;
}

export function PropertiesPanel({ 
  componentType = "wing",
  parameters = {},
  lastPrompt = ""
}: PropertiesPanelProps) {
  const [designName, setDesignName] = useState("");
  const [designDescription, setDesignDescription] = useState("");
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [metalness, setMetalness] = useState(0.7);
  const [roughness, setRoughness] = useState(0.3);
  const [exportFormat, setExportFormat] = useState("glb");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const saveDesignMutation = useMutation({
    mutationFn: async (data: { name: string; description: string }) => {
      const response = await apiRequest("POST", "/api/designs", {
        userId: null,
        name: data.name,
        description: data.description,
        componentType,
        parameters: {
          componentType,
          ...parameters,
        },
        prompt: lastPrompt,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to save design");
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/designs"] });
      toast({
        title: "Design Saved",
        description: "Your aircraft design has been saved successfully",
      });
      setSaveDialogOpen(false);
      setDesignName("");
      setDesignDescription("");
    },
    onError: (error) => {
      toast({
        title: "Save Failed",
        description: error instanceof Error ? error.message : "Failed to save design",
        variant: "destructive",
      });
    },
  });

  const handleSaveDesign = () => {
    if (!designName.trim()) {
      toast({
        title: "Name Required",
        description: "Please enter a name for your design",
        variant: "destructive",
      });
      return;
    }
    
    saveDesignMutation.mutate({
      name: designName,
      description: designDescription,
    });
  };

  const componentTitle = {
    wing: "Wing Component",
    fuselage: "Fuselage Component",
    complete: "Complete Aircraft",
  }[componentType];

  return (
    <div className="h-full flex flex-col bg-card border-l">
      <div className="p-4 border-b">
        <h2 className="font-semibold">Properties</h2>
        <p className="text-sm text-muted-foreground">{componentTitle}</p>
      </div>

      <Tabs defaultValue="parameters" className="flex-1 flex flex-col">
        <TabsList className="mx-4 mt-2 grid grid-cols-3">
          <TabsTrigger value="parameters" data-testid="tab-parameters">
            <Settings className="h-3 w-3 mr-1" />
            Parameters
          </TabsTrigger>
          <TabsTrigger value="materials" data-testid="tab-materials">
            <Palette className="h-3 w-3 mr-1" />
            Materials
          </TabsTrigger>
          <TabsTrigger value="export" data-testid="tab-export">
            <FileDown className="h-3 w-3 mr-1" />
            Export
          </TabsTrigger>
        </TabsList>

        <ScrollArea className="flex-1">
          <TabsContent value="parameters" className="p-4 space-y-4 m-0">
            {(componentType === "wing" || componentType === "complete") && (
              <div className="space-y-1">
                <h3 className="text-sm font-medium mb-3">Wing Geometry</h3>
                {parameters.sweep !== undefined && (
                  <div className="p-3 rounded-md bg-muted/30 space-y-1">
                    <div className="text-sm font-medium">Sweep Angle</div>
                    <div className="text-2xl font-bold">{parameters.sweep}°</div>
                  </div>
                )}
                {parameters.span !== undefined && (
                  <div className="p-3 rounded-md bg-muted/30 space-y-1">
                    <div className="text-sm font-medium">Wingspan</div>
                    <div className="text-2xl font-bold">{parameters.span}m</div>
                  </div>
                )}
                {parameters.chord !== undefined && (
                  <div className="p-3 rounded-md bg-muted/30 space-y-1">
                    <div className="text-sm font-medium">Chord Length</div>
                    <div className="text-2xl font-bold">{parameters.chord}m</div>
                  </div>
                )}
              </div>
            )}
            
            {(componentType === "fuselage" || componentType === "complete") && (
              <div className="space-y-1">
                <h3 className="text-sm font-medium mb-3">Fuselage Geometry</h3>
                {parameters.length !== undefined && (
                  <div className="p-3 rounded-md bg-muted/30 space-y-1">
                    <div className="text-sm font-medium">Length</div>
                    <div className="text-2xl font-bold">{parameters.length}m</div>
                  </div>
                )}
                {parameters.diameter !== undefined && (
                  <div className="p-3 rounded-md bg-muted/30 space-y-1">
                    <div className="text-sm font-medium">Diameter</div>
                    <div className="text-2xl font-bold">{parameters.diameter}m</div>
                  </div>
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="materials" className="p-4 space-y-4 m-0">
            <div className="space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-sm">Metalness</Label>
                  <span className="text-xs text-muted-foreground font-mono">
                    {metalness.toFixed(2)}
                  </span>
                </div>
                <Slider
                  value={[metalness]}
                  onValueChange={(value) => setMetalness(value[0])}
                  min={0}
                  max={1}
                  step={0.01}
                  className="w-full"
                  data-testid="slider-metalness"
                />
                <p className="text-xs text-muted-foreground">
                  Controls how metal-like the material appears
                </p>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-sm">Roughness</Label>
                  <span className="text-xs text-muted-foreground font-mono">
                    {roughness.toFixed(2)}
                  </span>
                </div>
                <Slider
                  value={[roughness]}
                  onValueChange={(value) => setRoughness(value[0])}
                  min={0}
                  max={1}
                  step={0.01}
                  className="w-full"
                  data-testid="slider-roughness"
                />
                <p className="text-xs text-muted-foreground">
                  Controls surface smoothness and reflectivity
                </p>
              </div>
              
              <div className="p-3 rounded-md bg-muted/30 space-y-2">
                <div className="text-sm font-medium">Material Preview</div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="h-16 rounded-md bg-gradient-to-br from-slate-400 to-slate-600" />
                  <div className="h-16 rounded-md bg-gradient-to-br from-blue-400 to-blue-600" />
                  <div className="h-16 rounded-md bg-gradient-to-br from-orange-400 to-orange-600" />
                </div>
                <p className="text-xs text-muted-foreground">
                  Click to apply preset materials
                </p>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="export" className="p-4 space-y-4 m-0">
            <div className="space-y-3">
              <div className="space-y-2">
                <Label className="text-sm">Export Format</Label>
                <Select value={exportFormat} onValueChange={setExportFormat}>
                  <SelectTrigger data-testid="select-export-format">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="glb">GLB (Binary GLTF)</SelectItem>
                    <SelectItem value="gltf">GLTF (Text)</SelectItem>
                    <SelectItem value="obj">OBJ</SelectItem>
                    <SelectItem value="stl">STL</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  GLB recommended for most applications
                </p>
              </div>
              
              <div className="p-3 rounded-md bg-muted/30 space-y-2">
                <div className="text-sm font-medium">Export Settings</div>
                <div className="space-y-1 text-xs text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Include Materials</span>
                    <span className="text-foreground">✓ Yes</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Include Textures</span>
                    <span className="text-foreground">✓ Yes</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Optimize Size</span>
                    <span className="text-foreground">✓ Yes</span>
                  </div>
                </div>
              </div>
              
              <Button
                variant="default"
                className="w-full"
                onClick={() => console.log(`Export as ${exportFormat}`)}
                data-testid="button-export-model"
              >
                <Download className="h-4 w-4 mr-2" />
                Download {exportFormat.toUpperCase()}
              </Button>
              
              <div className="p-3 rounded-md bg-primary/10 border border-primary/20">
                <div className="text-sm font-medium text-primary mb-1">Pro Tip</div>
                <p className="text-xs text-muted-foreground">
                  Use GLB format for web applications and game engines. Use STEP or STL for 3D printing and manufacturing.
                </p>
              </div>
            </div>
          </TabsContent>
        </ScrollArea>
      </Tabs>

      <div className="p-4 border-t space-y-2">
        <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
          <DialogTrigger asChild>
            <Button
              className="w-full"
              variant="default"
              data-testid="button-save"
            >
              <Save className="h-4 w-4 mr-2" />
              Save Design
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Save Aircraft Design</DialogTitle>
              <DialogDescription>
                Save your aircraft design to load it later
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Design Name *</Label>
                <Input
                  id="name"
                  placeholder="e.g., Fighter Jet Wing V1"
                  value={designName}
                  onChange={(e) => setDesignName(e.target.value)}
                  data-testid="input-design-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description (optional)</Label>
                <Input
                  id="description"
                  placeholder="Additional details about this design"
                  value={designDescription}
                  onChange={(e) => setDesignDescription(e.target.value)}
                  data-testid="input-design-description"
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setSaveDialogOpen(false)}
                data-testid="button-cancel-save"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveDesign}
                disabled={saveDesignMutation.isPending}
                data-testid="button-confirm-save"
              >
                {saveDesignMutation.isPending ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        
        <Button
          variant="outline"
          className="w-full"
          onClick={() => console.log("Export clicked")}
          data-testid="button-export"
        >
          <Download className="h-4 w-4 mr-2" />
          Export Model
        </Button>
      </div>
    </div>
  );
}
