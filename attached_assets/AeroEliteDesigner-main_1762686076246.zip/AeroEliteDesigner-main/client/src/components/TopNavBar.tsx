import { Plane, Save, FolderOpen, Plus, User, LogOut, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "./ThemeToggle";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface TopNavBarProps {
  onExport?: () => void;
}

export function TopNavBar({ onExport }: TopNavBarProps = {}) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: authData } = useQuery<{ user: any }>({
    queryKey: ["/api/auth/user"],
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/auth/logout", {});
      if (!response.ok) {
        throw new Error("Failed to logout");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.clear();
      window.location.href = "/login";
    },
    onError: () => {
      toast({
        title: "Logout Failed",
        description: "Failed to sign out. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const userInitials = authData?.user?.username
    ?.split("@")[0]
    ?.slice(0, 2)
    ?.toUpperCase() || "U";

  return (
    <header className="h-16 border-b bg-card flex items-center justify-between px-4 gap-4">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Plane className="h-6 w-6 text-primary" />
          <span className="text-lg font-semibold">Aero Elite</span>
        </div>
        <div className="hidden md:flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            data-testid="button-new-design"
            onClick={() => console.log("New design clicked")}
          >
            <Plus className="h-4 w-4 mr-2" />
            New Design
          </Button>
          <Button
            variant="ghost"
            size="sm"
            data-testid="button-open"
            onClick={() => console.log("Open clicked")}
          >
            <FolderOpen className="h-4 w-4 mr-2" />
            Open
          </Button>
          <Button
            variant="ghost"
            size="sm"
            data-testid="button-save"
            onClick={() => console.log("Save clicked")}
          >
            <Save className="h-4 w-4 mr-2" />
            Save
          </Button>
          <Button
            variant="ghost"
            size="sm"
            data-testid="button-export"
            onClick={onExport}
            disabled={!onExport}
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>
      
      <div className="flex items-center gap-2">
        <ThemeToggle />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9"
              data-testid="button-user-menu"
            >
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-primary text-primary-foreground">
                  {userInitials}
                </AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <div className="px-2 py-1.5 text-sm">
              <div className="font-medium">Signed in as</div>
              <div className="text-xs text-muted-foreground truncate">
                {authData?.user?.username || "User"}
              </div>
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuItem data-testid="menu-profile">
              <User className="h-4 w-4 mr-2" />
              Profile
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              onClick={handleLogout} 
              data-testid="menu-logout"
              disabled={logoutMutation.isPending}
            >
              <LogOut className="h-4 w-4 mr-2" />
              {logoutMutation.isPending ? "Signing out..." : "Sign Out"}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
