import DesignStudio from "../DesignStudio";
import { ThemeProvider } from "@/components/ThemeProvider";

export default function DesignStudioExample() {
  return (
    <ThemeProvider>
      <DesignStudio />
    </ThemeProvider>
  );
}
