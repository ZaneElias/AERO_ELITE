import { useState, useRef } from "react";
import { SidebarProvider, Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel } from "@/components/ui/sidebar";
import { TopNavBar } from "@/components/TopNavBar";
import { Aircraft3DViewer, Aircraft3DViewerRef } from "@/components/Aircraft3DViewer";
import { PropertiesPanel } from "@/components/PropertiesPanel";
import { NaturalLanguageInput } from "@/components/NaturalLanguageInput";
import { ComponentLibrary } from "@/components/ComponentLibrary";
import { MeshyGenerator } from "@/components/MeshyGenerator";
import { ViewControls } from "@/components/ViewControls";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import type { AircraftParameters, AircraftDesign } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function DesignStudio() {
  const [componentType, setComponentType] = useState<"wing" | "fuselage" | "complete">("wing");
  const [parameters, setParameters] = useState({
    sweep: 35,
    span: 35,
    chord: 8,
    length: 40,
    diameter: 4,
  });
  const [lastPrompt, setLastPrompt] = useState<string>("");
  const { toast } = useToast();
  const aircraft3DViewerRef = useRef<Aircraft3DViewerRef>(null);

  const handleParametersExtracted = (extractedParams: AircraftParameters, explanation: string, prompt: string) => {
    console.log("Extracted parameters:", extractedParams);
    console.log("Explanation:", explanation);
    
    setLastPrompt(prompt);
    
    // Update component type
    if (extractedParams.componentType) {
      setComponentType(extractedParams.componentType as "wing" | "fuselage" | "complete");
    }
    
    // Update parameters
    setParameters({
      sweep: extractedParams.sweep || parameters.sweep,
      span: extractedParams.span || parameters.span,
      chord: extractedParams.chord || parameters.chord,
      length: extractedParams.length || parameters.length,
      diameter: extractedParams.diameter || parameters.diameter,
    });
    
    toast({
      title: "Model Updated",
      description: explanation,
    });
  };

  const handleLoadDesign = (design: AircraftDesign) => {
    console.log("Loading design:", design);
    
    try {
      // Extract parameters from saved design
      const savedParams = design.parameters as any || {};
      
      // Update component type
      if (design.componentType) {
        setComponentType(design.componentType as "wing" | "fuselage" | "complete");
      }
      
      // Update parameters from saved design
      setParameters({
        sweep: savedParams.sweep || parameters.sweep,
        span: savedParams.span || parameters.span,
        chord: savedParams.chord || parameters.chord,
        length: savedParams.length || parameters.length,
        diameter: savedParams.diameter || parameters.diameter,
      });
      
      // Update last prompt if available
      if (design.prompt) {
        setLastPrompt(design.prompt);
      }
      
      toast({
        title: "Design Loaded",
        description: `Loaded ${design.name}`,
      });
    } catch (error) {
      console.error("Error loading design:", error);
      toast({
        title: "Load Failed",
        description: "Failed to load saved design",
        variant: "destructive",
      });
    }
  };

  const handleExport = () => {
    if (aircraft3DViewerRef.current) {
      aircraft3DViewerRef.current.exportModel();
    }
  };

  const sidebarStyle = {
    "--sidebar-width": "20rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <Sidebar>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>Parametric Generator (Free)</SidebarGroupLabel>
              <SidebarGroupContent className="px-4 py-2 space-y-2">
                <NaturalLanguageInput onParametersExtracted={handleParametersExtracted} />
              </SidebarGroupContent>
            </SidebarGroup>
            
            <Separator className="my-2" />
            
            <SidebarGroup>
              <SidebarGroupLabel>AI Photorealistic (Optional)</SidebarGroupLabel>
              <SidebarGroupContent className="px-4 py-2 space-y-2">
                <p className="text-xs text-muted-foreground mb-2">
                  Meshy AI generates photorealistic 3D models but requires a paid subscription (~$16/month).
                </p>
                <MeshyGenerator 
                  onMeshGenerated={(taskId, modelUrl) => {
                    toast({
                      title: "Meshy Model Ready",
                      description: `Task ID: ${taskId}`,
                    });
                  }}
                />
              </SidebarGroupContent>
            </SidebarGroup>
            
            <SidebarGroup>
              <ScrollArea className="flex-1">
                <ComponentLibrary onLoadDesign={handleLoadDesign} />
              </ScrollArea>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        <div className="flex flex-col flex-1">
          <TopNavBar onExport={handleExport} />
          
          <main className="flex-1 flex overflow-hidden">
            <div className="flex-1 relative">
              <Aircraft3DViewer
                ref={aircraft3DViewerRef}
                componentType={componentType}
                parameters={parameters}
              />
              <ViewControls viewerRef={aircraft3DViewerRef} />
            </div>
            
            <div className="w-80 flex-shrink-0">
              <PropertiesPanel 
                componentType={componentType}
                parameters={parameters}
                lastPrompt={lastPrompt}
              />
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
