import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, timestamp, jsonb, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Aircraft designs table for saving user-created aircraft models
export const aircraftDesigns = pgTable("aircraft_designs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  name: text("name").notNull(),
  description: text("description"),
  componentType: text("component_type").notNull(),
  parameters: jsonb("parameters").notNull(),
  prompt: text("prompt"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertAircraftDesignSchema = createInsertSchema(aircraftDesigns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertAircraftDesign = z.infer<typeof insertAircraftDesignSchema>;
export type AircraftDesign = typeof aircraftDesigns.$inferSelect;

// Aircraft templates table - pre-built example aircraft for users to load
export const aircraftTemplates = pgTable("aircraft_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  componentType: text("component_type").notNull(),
  parameters: jsonb("parameters").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  isPublic: real("is_public").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAircraftTemplateSchema = createInsertSchema(aircraftTemplates).omit({
  id: true,
  createdAt: true,
});

export type InsertAircraftTemplate = z.infer<typeof insertAircraftTemplateSchema>;
export type AircraftTemplate = typeof aircraftTemplates.$inferSelect;

// Aircraft design parameters schema - constrained to supported viewer types
export const aircraftParametersSchema = z.object({
  componentType: z.enum(["wing", "fuselage", "complete"]),
  sweep: z.number().optional(),
  span: z.number().optional(),
  chord: z.number().optional(),
  length: z.number().optional(),
  diameter: z.number().optional(),
  thickness: z.number().optional(),
  material: z.string().optional(),
  thrust: z.number().optional(),
  count: z.number().optional(),
});

export type AircraftParameters = z.infer<typeof aircraftParametersSchema>;

// Full component types for future expansion
export type AllComponentTypes = "wing" | "fuselage" | "engine" | "tail" | "landing_gear" | "complete";

// API request/response types
export const extractParametersRequestSchema = z.object({
  prompt: z.string().min(1).max(1000),
});

export type ExtractParametersRequest = z.infer<typeof extractParametersRequestSchema>;

export interface ExtractParametersResponse {
  parameters: AircraftParameters;
  explanation: string;
}

// Validation schemas for API endpoints
export const designIdParamSchema = z.object({
  id: z.string().regex(/^\d+$/, "ID must be a positive integer").transform(Number),
});

export const userIdQuerySchema = z.object({
  userId: z.string().optional(),
});
