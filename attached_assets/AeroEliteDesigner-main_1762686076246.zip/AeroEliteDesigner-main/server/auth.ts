import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import type { Express } from "express";
import session from "express-session";
import { db } from "./db";
import { users } from "@shared/schema";
import { eq } from "drizzle-orm";

// Validate and type-narrow required environment variables
if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
  throw new Error("GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET must be set");
}

if (!process.env.SESSION_SECRET) {
  throw new Error("SESSION_SECRET must be set for secure session management");
}

const GOOGLE_CLIENT_ID: string = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET: string = process.env.GOOGLE_CLIENT_SECRET;
const SESSION_SECRET: string = process.env.SESSION_SECRET;

// Construct the full callback URL for OAuth
function getCallbackURL(): string {
  // In Replit, use REPLIT_DEV_DOMAIN for development
  if (process.env.REPLIT_DEV_DOMAIN) {
    return `https://${process.env.REPLIT_DEV_DOMAIN}/auth/google/callback`;
  }
  
  // Fallback to localhost for local development
  const port = process.env.PORT || 5000;
  return `http://localhost:${port}/auth/google/callback`;
}

const CALLBACK_URL = getCallbackURL();
console.log(`[OAuth] Using callback URL: ${CALLBACK_URL}`);

// Configure Google OAuth Strategy
passport.use(
  new GoogleStrategy(
    {
      clientID: GOOGLE_CLIENT_ID,
      clientSecret: GOOGLE_CLIENT_SECRET,
      callbackURL: CALLBACK_URL,
    },
    async (_accessToken, _refreshToken, profile, done) => {
      try {
        // Extract user info from Google profile
        const googleId = profile.id;
        const email = profile.emails?.[0]?.value;
        const displayName = profile.displayName || email || googleId;

        if (!email) {
          return done(new Error("No email found in Google profile"));
        }

        // Check if user exists
        const existingUsers = await db
          .select()
          .from(users)
          .where(eq(users.username, email))
          .limit(1);

        let user;
        if (existingUsers.length > 0) {
          user = existingUsers[0];
        } else {
          // Create new user
          const newUsers = await db
            .insert(users)
            .values({
              username: email,
              password: `google_${googleId}`, // Not used for OAuth, just a placeholder
            })
            .returning();
          user = newUsers[0];
        }

        return done(null, user);
      } catch (error) {
        return done(error as Error);
      }
    }
  )
);

// Serialize user to session
passport.serializeUser((user: any, done) => {
  done(null, user.id);
});

// Deserialize user from session
passport.deserializeUser(async (id: string, done) => {
  try {
    const userResults = await db
      .select()
      .from(users)
      .where(eq(users.id, id))
      .limit(1);

    if (userResults.length === 0) {
      return done(new Error("User not found"));
    }

    done(null, userResults[0]);
  } catch (error) {
    done(error);
  }
});

export function setupAuth(app: Express) {
  // Session configuration
  app.use(
    session({
      secret: SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        httpOnly: true,
        maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      },
    })
  );

  // Initialize Passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Google OAuth routes
  app.get("/auth/google", (req, res, next) => {
    console.log("[OAuth] Initiating Google authentication");
    passport.authenticate("google", { scope: ["profile", "email"] })(req, res, next);
  });

  app.get(
    "/auth/google/callback",
    (req, res, next) => {
      console.log("[OAuth] Received callback from Google");
      passport.authenticate("google", {
        failureRedirect: "/login",
        failureMessage: true,
      })(req, res, next);
    },
    (req, res) => {
      console.log("[OAuth] Authentication successful, user:", req.user);
      res.redirect("/");
    }
  );

  // Error handler for OAuth failures
  app.get("/login", (req, res) => {
    const session = req.session as any;
    const errorMessage = session?.messages?.[0] || "Authentication failed";
    console.error("[OAuth] Authentication failed:", errorMessage);
    res.redirect(`/?error=${encodeURIComponent(errorMessage)}`);
  });

  // Logout route
  app.post("/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ error: "Failed to logout" });
      }
      res.json({ success: true });
    });
  });

  // Get current user
  app.get("/api/auth/user", (req, res) => {
    if (req.isAuthenticated()) {
      res.json({ user: req.user });
    } else {
      res.status(401).json({ error: "Not authenticated" });
    }
  });
}

// Middleware to protect routes
export function requireAuth(req: any, res: any, next: any) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ error: "Authentication required" });
}
