import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  extractParametersRequestSchema, 
  insertAircraftDesignSchema,
  designIdParamSchema,
  userIdQuerySchema
} from "@shared/schema";
import { extractAircraftParameters } from "./ai/gemini";
import { createMeshyPreviewTask, getMeshyTaskStatus, createMeshyRefineTask } from "./ai/meshy";
import { ZodError } from "zod";
import { requireAuth } from "./auth";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // AI parameter extraction endpoint
  app.post("/api/extract-parameters", async (req, res) => {
    try {
      const { prompt } = extractParametersRequestSchema.parse(req.body);
      
      const result = await extractAircraftParameters(prompt);
      
      console.log("AI extracted parameters:", result.parameters);
      res.json(result);
    } catch (error) {
      console.error("Error in extract-parameters:", error);
      const statusCode = error instanceof Error && 
        (error.message.includes("invalid") || error.message.includes("did not")) 
        ? 400 
        : 500;
      
      res.status(statusCode).json({ 
        error: error instanceof Error ? error.message : "Failed to extract parameters" 
      });
    }
  });

  // Aircraft design CRUD endpoints - Protected with authentication
  app.post("/api/designs", requireAuth, async (req: any, res) => {
    try {
      const design = insertAircraftDesignSchema.parse(req.body);
      // Override userId with authenticated user's ID for security
      const created = await storage.createAircraftDesign({
        ...design,
        userId: req.user.id,
      });
      res.status(201).json(created);
    } catch (error) {
      console.error("Error creating design:", error);
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          error: "Invalid request data",
          details: error.errors
        });
      }
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to create design" 
      });
    }
  });

  app.get("/api/designs", requireAuth, async (req: any, res) => {
    try {
      // Always fetch designs for the authenticated user only
      const designs = await storage.getAircraftDesignsByUser(req.user.id);
      res.json(designs);
    } catch (error) {
      console.error("Error fetching designs:", error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to fetch designs" 
      });
    }
  });

  app.get("/api/designs/:id", requireAuth, async (req: any, res) => {
    try {
      const { id } = designIdParamSchema.parse(req.params);
      const design = await storage.getAircraftDesign(id);
      if (!design) {
        return res.status(404).json({ error: "Design not found" });
      }
      // Verify user owns this design for security
      if (design.userId !== req.user.id) {
        return res.status(403).json({ error: "Forbidden - you don't own this design" });
      }
      res.json(design);
    } catch (error) {
      console.error("Error fetching design:", error);
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          error: "Invalid design ID - must be a positive integer"
        });
      }
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to fetch design" 
      });
    }
  });

  app.patch("/api/designs/:id", requireAuth, async (req: any, res) => {
    try {
      const { id } = designIdParamSchema.parse(req.params);
      const design = await storage.getAircraftDesign(id);
      if (!design) {
        return res.status(404).json({ error: "Design not found" });
      }
      // Verify user owns this design for security
      if (design.userId !== req.user.id) {
        return res.status(403).json({ error: "Forbidden - you don't own this design" });
      }
      const updates = insertAircraftDesignSchema.partial().parse(req.body);
      const updated = await storage.updateAircraftDesign(id, updates);
      res.json(updated);
    } catch (error) {
      console.error("Error updating design:", error);
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          error: "Invalid request data",
          details: error.errors
        });
      }
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to update design" 
      });
    }
  });

  app.delete("/api/designs/:id", requireAuth, async (req: any, res) => {
    try {
      const { id } = designIdParamSchema.parse(req.params);
      const design = await storage.getAircraftDesign(id);
      if (!design) {
        return res.status(404).json({ error: "Design not found" });
      }
      // Verify user owns this design for security
      if (design.userId !== req.user.id) {
        return res.status(403).json({ error: "Forbidden - you don't own this design" });
      }
      await storage.deleteAircraftDesign(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting design:", error);
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          error: "Invalid design ID - must be a positive integer"
        });
      }
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to delete design" 
      });
    }
  });

  // Aircraft templates endpoints - Public access for browsing
  app.get("/api/templates", async (req, res) => {
    try {
      const templates = await storage.getAllAircraftTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching templates:", error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to fetch templates" 
      });
    }
  });

  app.get("/api/templates/:id", async (req, res) => {
    try {
      const { id } = designIdParamSchema.parse(req.params);
      const template = await storage.getAircraftTemplate(id);
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }
      res.json(template);
    } catch (error) {
      console.error("Error fetching template:", error);
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          error: "Invalid template ID - must be a positive integer"
        });
      }
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to fetch template" 
      });
    }
  });

  // Meshy API endpoints for advanced 3D generation
  const meshyPreviewRequestSchema = z.object({
    prompt: z.string().min(1).max(600),
    negativePrompt: z.string().optional(),
    artStyle: z.enum(["realistic", "cartoon", "low-poly", "sculpture", "pbr"]).optional(),
    shouldRemesh: z.boolean().optional(),
    enablePbr: z.boolean().optional(),
  });

  app.post("/api/meshy/preview", requireAuth, async (req, res) => {
    try {
      const request = meshyPreviewRequestSchema.parse(req.body);
      const result = await createMeshyPreviewTask(request);
      res.json(result);
    } catch (error) {
      console.error("Error creating Meshy preview task:", error);
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          error: "Invalid request data",
          details: error.errors
        });
      }
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to create preview task" 
      });
    }
  });

  app.get("/api/meshy/task/:taskId", requireAuth, async (req, res) => {
    try {
      const { taskId } = req.params;
      if (!taskId) {
        return res.status(400).json({ error: "Task ID is required" });
      }
      const status = await getMeshyTaskStatus(taskId);
      res.json(status);
    } catch (error) {
      console.error("Error fetching Meshy task status:", error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to fetch task status" 
      });
    }
  });

  app.post("/api/meshy/refine", requireAuth, async (req, res) => {
    try {
      const { previewTaskId } = z.object({ previewTaskId: z.string() }).parse(req.body);
      const result = await createMeshyRefineTask(previewTaskId);
      res.json(result);
    } catch (error) {
      console.error("Error creating Meshy refine task:", error);
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          error: "Invalid request data",
          details: error.errors
        });
      }
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to create refine task" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
