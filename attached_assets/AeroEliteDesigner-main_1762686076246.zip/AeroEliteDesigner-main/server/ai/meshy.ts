const MESHY_API_KEY = process.env.MESHY_API_KEY;
const MESHY_BASE_URL = "https://api.meshy.ai/openapi/v2";

if (!MESHY_API_KEY) {
  console.warn("⚠️  MESHY_API_KEY not found. Meshy 3D generation features will not work.");
}

export interface MeshyPreviewRequest {
  prompt: string;
  negativePrompt?: string;
  artStyle?: "realistic" | "cartoon" | "low-poly" | "sculpture" | "pbr";
  shouldRemesh?: boolean;
  enablePbr?: boolean;
}

export interface MeshyTaskStatus {
  id: string;
  status: "PENDING" | "IN_PROGRESS" | "SUCCEEDED" | "FAILED";
  progress: number;
  model_urls?: {
    glb?: string;
    fbx?: string;
    usdz?: string;
    obj?: string;
  };
  thumbnail_url?: string;
  video_url?: string;
  error?: string;
}

export async function createMeshyPreviewTask(request: MeshyPreviewRequest): Promise<{ taskId: string }> {
  if (!MESHY_API_KEY) {
    throw new Error("Meshy API key not configured. Please add MESHY_API_KEY to your environment variables.");
  }

  try {
    const response = await fetch(`${MESHY_BASE_URL}/text-to-3d`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${MESHY_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        mode: "preview",
        prompt: request.prompt,
        negative_prompt: request.negativePrompt || "low quality, low resolution, low poly, ugly",
        art_style: request.artStyle || "realistic",
        should_remesh: request.shouldRemesh !== false,
        enable_pbr: request.enablePbr !== false,
      }),
    });

    if (!response.ok) {
      if (response.status === 402) {
        throw new Error("Meshy API subscription required. Please upgrade your plan at meshy.ai/settings/subscription");
      }
      if (response.status === 401) {
        throw new Error("Invalid Meshy API key. Please check your MESHY_API_KEY environment variable.");
      }
      const errorText = await response.text();
      let errorMessage = `Meshy API error (${response.status})`;
      try {
        const errorJson = JSON.parse(errorText);
        errorMessage += `: ${errorJson.message || errorJson.error || errorText}`;
      } catch {
        errorMessage += `: ${errorText}`;
      }
      throw new Error(errorMessage);
    }

    const data = await response.json();
    
    if (!data.result) {
      throw new Error("Invalid Meshy API response: missing result field");
    }
    
    return { taskId: data.result };
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error("Failed to create Meshy preview task: " + String(error));
  }
}

export async function getMeshyTaskStatus(taskId: string): Promise<MeshyTaskStatus> {
  if (!MESHY_API_KEY) {
    throw new Error("Meshy API key not configured");
  }

  try {
    const response = await fetch(`${MESHY_BASE_URL}/text-to-3d/${taskId}`, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${MESHY_API_KEY}`,
      },
    });

    if (!response.ok) {
      if (response.status === 402) {
        throw new Error("Meshy API subscription required. Please upgrade your plan at meshy.ai/settings/subscription");
      }
      if (response.status === 404) {
        throw new Error("Meshy task not found. The task may have expired or been deleted.");
      }
      const errorText = await response.text();
      let errorMessage = `Meshy API error (${response.status})`;
      try {
        const errorJson = JSON.parse(errorText);
        errorMessage += `: ${errorJson.message || errorJson.error || errorText}`;
      } catch {
        errorMessage += `: ${errorText}`;
      }
      throw new Error(errorMessage);
    }

    const data = await response.json();
    
    return {
      id: data.id || taskId,
      status: data.status || "PENDING",
      progress: data.progress || 0,
      model_urls: data.model_urls,
      thumbnail_url: data.thumbnail_url,
      video_url: data.video_url,
      error: data.task_error?.message,
    };
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error("Failed to get Meshy task status: " + String(error));
  }
}

export async function createMeshyRefineTask(previewTaskId: string): Promise<{ taskId: string }> {
  if (!MESHY_API_KEY) {
    throw new Error("Meshy API key not configured");
  }

  const response = await fetch(`${MESHY_BASE_URL}/text-to-3d`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${MESHY_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      mode: "refine",
      preview_task_id: previewTaskId,
      enable_pbr: true,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Meshy API error (${response.status}): ${error}`);
  }

  const data = await response.json();
  
  // Meshy API returns { result: "task-id" }
  if (!data.result) {
    throw new Error("Invalid Meshy API response: missing result field");
  }
  
  return { taskId: data.result };
}
