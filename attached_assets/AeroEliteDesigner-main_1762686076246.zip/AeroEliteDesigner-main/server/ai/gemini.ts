import { GoogleGenAI } from "@google/genai";
import type { AircraftParameters } from "@shared/schema";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
});

const SYSTEM_PROMPT = `You are an expert aerospace engineer assistant specializing in aircraft design and parametric modeling. Extract aircraft component design parameters from natural language descriptions with high accuracy.

COMPONENT TYPES (choose the best match):
- "wing": Main lifting surface, delta wings, swept wings
- "fuselage": Main body/cabin, nose section, tail section  
- "complete": Full aircraft assembly with all components

AEROSPACE TERMINOLOGY GUIDE:
- Sweep angle: 0-65° (0°=straight, 25°=commercial, 35-45°=fighter, 60°+=delta)
- Wingspan: 10-80m (10-15m=small, 20-40m=medium, 60-80m=large commercial)
- Chord: 2-12m (root chord of wing)
- Length: 15-75m (fuselage length, 15-25m=small, 40-50m=medium, 70m+=jumbo)
- Diameter: 2-8m (fuselage diameter, 2-3m=narrow body, 5-6m=wide body)
- Material: aluminum alloy, titanium, carbon composite, composite materials

COMMON AIRCRAFT EXAMPLES:
- F-16 Fighter: wing sweep=40°, span=9.8m, chord=3m, fuselage length=15m, diameter=1.2m
- Boeing 737: wing sweep=25°, span=35m, chord=7m, fuselage length=38m, diameter=3.8m
- Boeing 747: wing sweep=37°, span=68m, chord=12m, fuselage length=70m, diameter=6.5m
- Cessna 172: wing sweep=0°, span=11m, chord=1.6m, fuselage length=8m, diameter=1.2m
- F-22 Raptor: wing sweep=42°, span=13.6m, chord=4m, fuselage length=19m, diameter=1.5m
- A380: wing sweep=33°, span=80m, chord=14m, fuselage length=73m, diameter=7.1m

EXTRACTION RULES:
1. If user mentions "fighter jet/military aircraft" → use sweep=35-45°, span=10-15m
2. If user mentions "commercial airliner/passenger plane" → use sweep=25-35°, span=30-70m
3. If user mentions "small aircraft/private plane" → use sweep=0-10°, span=8-15m
4. If specific aircraft name given (F-16, 737, etc.) → use realistic specs from examples
5. Always infer reasonable defaults based on aircraft type if values not specified
6. Material defaults: "aluminum alloy" for commercial, "composite materials" for modern/fighter

Return ONLY valid JSON with extracted parameters. Infer missing values intelligently based on aircraft type.

Example outputs:
Input: "Design a fighter jet wing"
Output: {"componentType": "wing", "sweep": 40, "span": 12, "chord": 3.5, "material": "composite materials"}

Input: "Create a Boeing 737 fuselage"  
Output: {"componentType": "fuselage", "length": 38, "diameter": 3.8, "material": "aluminum alloy"}

Input: "Build a complete F-16 aircraft"
Output: {"componentType": "complete", "sweep": 40, "span": 9.8, "chord": 3, "length": 15, "diameter": 1.2, "material": "composite materials"}`;

export async function extractAircraftParameters(
  prompt: string
): Promise<{ parameters: AircraftParameters; explanation: string }> {
  try {
    const fullPrompt = `${SYSTEM_PROMPT}

User description: ${prompt}

Extract parameters as JSON:`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: fullPrompt,
    });

    const text = response.text || "";
    
    if (!text) {
      throw new Error("No response from AI model");
    }

    // Try to parse JSON from the response
    let parameters: Partial<AircraftParameters> = {};
    let explanation = "";

    // Extract JSON from markdown code blocks or plain text
    const jsonMatch = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || text.match(/\{[\s\S]*\}/);
    
    if (jsonMatch) {
      const jsonText = jsonMatch[1] || jsonMatch[0];
      try {
        parameters = JSON.parse(jsonText);
      } catch (e) {
        console.error("Failed to parse JSON from Gemini response:", e);
        console.error("Response text:", text);
        throw new Error("AI returned invalid JSON format");
      }
    } else {
      console.error("No JSON found in response:", text);
      throw new Error("AI did not return valid parameters");
    }

    // Validate required componentType
    if (!parameters.componentType) {
      throw new Error("AI did not specify component type");
    }

    // Set defaults for common parameters based on component type
    const finalParameters: AircraftParameters = {
      componentType: parameters.componentType as any,
      sweep: parameters.sweep,
      span: parameters.span,
      chord: parameters.chord,
      length: parameters.length,
      diameter: parameters.diameter,
      material: parameters.material,
      thickness: parameters.thickness,
      thrust: parameters.thrust,
      count: parameters.count,
    };

    // Generate explanation
    explanation = `Generated ${finalParameters.componentType} component with the following specifications:`;
    if (finalParameters.sweep) explanation += `\n- Sweep angle: ${finalParameters.sweep}°`;
    if (finalParameters.span) explanation += `\n- Span: ${finalParameters.span}m`;
    if (finalParameters.chord) explanation += `\n- Chord: ${finalParameters.chord}m`;
    if (finalParameters.length) explanation += `\n- Length: ${finalParameters.length}m`;
    if (finalParameters.diameter) explanation += `\n- Diameter: ${finalParameters.diameter}m`;
    if (finalParameters.material) explanation += `\n- Material: ${finalParameters.material}`;
    if (finalParameters.thrust) explanation += `\n- Thrust: ${finalParameters.thrust}kN`;
    if (finalParameters.count) explanation += `\n- Count: ${finalParameters.count}`;

    return {
      parameters: finalParameters,
      explanation,
    };
  } catch (error) {
    console.error("Error extracting parameters with Gemini:", error);
    throw new Error(
      error instanceof Error 
        ? error.message 
        : "Failed to process aircraft component description"
    );
  }
}
