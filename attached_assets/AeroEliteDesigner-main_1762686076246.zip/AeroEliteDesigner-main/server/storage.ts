import { 
  type User, 
  type InsertUser,
  type AircraftDesign,
  type InsertAircraftDesign,
  type AircraftTemplate,
  users,
  aircraftDesigns,
  aircraftTemplates
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Aircraft design CRUD operations
  createAircraftDesign(design: InsertAircraftDesign): Promise<AircraftDesign>;
  getAircraftDesign(id: number): Promise<AircraftDesign | undefined>;
  getAircraftDesignsByUser(userId: string): Promise<AircraftDesign[]>;
  getAllAircraftDesigns(): Promise<AircraftDesign[]>;
  updateAircraftDesign(id: number, design: Partial<InsertAircraftDesign>): Promise<AircraftDesign | undefined>;
  deleteAircraftDesign(id: number): Promise<boolean>;
  
  // Aircraft template operations
  getAllAircraftTemplates(): Promise<AircraftTemplate[]>;
  getAircraftTemplate(id: number): Promise<AircraftTemplate | undefined>;
}

// Database storage implementation using PostgreSQL via Drizzle ORM
// Based on blueprint:javascript_database integration
export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Aircraft design methods
  async createAircraftDesign(design: InsertAircraftDesign): Promise<AircraftDesign> {
    const [created] = await db
      .insert(aircraftDesigns)
      .values(design)
      .returning();
    return created;
  }

  async getAircraftDesign(id: number): Promise<AircraftDesign | undefined> {
    const [design] = await db
      .select()
      .from(aircraftDesigns)
      .where(eq(aircraftDesigns.id, id));
    return design || undefined;
  }

  async getAircraftDesignsByUser(userId: string): Promise<AircraftDesign[]> {
    return await db
      .select()
      .from(aircraftDesigns)
      .where(eq(aircraftDesigns.userId, userId))
      .orderBy(desc(aircraftDesigns.updatedAt));
  }

  async getAllAircraftDesigns(): Promise<AircraftDesign[]> {
    return await db
      .select()
      .from(aircraftDesigns)
      .orderBy(desc(aircraftDesigns.updatedAt));
  }

  async updateAircraftDesign(id: number, design: Partial<InsertAircraftDesign>): Promise<AircraftDesign | undefined> {
    const [updated] = await db
      .update(aircraftDesigns)
      .set({ ...design, updatedAt: new Date() })
      .where(eq(aircraftDesigns.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteAircraftDesign(id: number): Promise<boolean> {
    const result = await db
      .delete(aircraftDesigns)
      .where(eq(aircraftDesigns.id, id))
      .returning();
    return result.length > 0;
  }
  
  // Aircraft template methods
  async getAllAircraftTemplates(): Promise<AircraftTemplate[]> {
    return await db
      .select()
      .from(aircraftTemplates)
      .orderBy(aircraftTemplates.category, aircraftTemplates.name);
  }
  
  async getAircraftTemplate(id: number): Promise<AircraftTemplate | undefined> {
    const [template] = await db
      .select()
      .from(aircraftTemplates)
      .where(eq(aircraftTemplates.id, id));
    return template || undefined;
  }
}

export const storage = new DatabaseStorage();
